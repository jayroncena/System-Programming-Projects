#include "20141535.h"
int main(void)
{
	int commandNumber;
	
	InitializeOpcodeTable();
	InitializeMemory();

	while(1)
	{
		printf("%s", shellStartCommand);
		//accept command from user
		scanf("%s",inputUser);
		
		commandNumber = GetCommandNumber(inputUser);
		numberOfInputCommand=0;
		
		switch(commandNumber)
		
		{
			case HELP:{
				Help();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case DIR_:{
				DirFunc();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case QUIT:{
				quit();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				FreeMemory();
				return 0;
			}
			case HISTORY:{
				History();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case DUMP:{
				ReadArguments();
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							errorFlag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							errorFlag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
						}
						else
						{
							ProcessDumpArgument();
							errorFlag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
						}
				
				FreeArguments();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case EDIT:{
				ReadArguments();
						if(dumpFlag == 0)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							errorFlag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							printf("MUST ENTER ADDRESS AND VALUE\n");
						}
						else if(dumpFlag ==1)
						{
							strcpy(cmdArgument[2].argument,"empty");
							errorFlag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							printf("MUST ENTER VALUE\n");
						}
						else
						{
							ProcessDumpArgument();
							errorFlag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
						}
				FreeArguments();
					errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case FILL:{
				ReadArguments();
						if(dumpFlag == 0)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							strcpy(cmdArgument[3].argument,"empty");
							errorFlag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("MUST ENTER START, END AND VALUE\n");
						}
						else if(dumpFlag ==1)
						{
							strcpy(cmdArgument[2].argument,"empty");
							strcpy(cmdArgument[3].argument,"empty");
							errorFlag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("MUST ENTER END AND VALUE\n");
						}
						else if(dumpFlag ==2)
						{
							ProcessDumpArgument();
							strcpy(cmdArgument[3].argument,"empty");
							errorFlag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("MUST ENTER VALUE\n");
						}
						else
						{
							ProcessDumpArgument();
							ProcessDumpArgument2();
							errorFlag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
						}
						FreeArguments();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case RESET:{
							for(int i=0; i != virtualMemory.columnOfMemory; ++i)
								for(int k=0; k!= virtualMemory.rowOfMemory;++k)
									virtualMemory.Memory[i][k] = 0;
					errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case OPCODE:{
				SearchPrintSpecificOpcode();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}	
			case OPCODELIST:{
				PrintOpcodeList();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case TYPE:{
				ReadFileContent();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case ASSEMBLE:{/*
				while(headSymbol!=NULL){
					temporarySymbol=headSymbol;
					headSymbol=headSymbol->link;
					free(temporarySymbol);
				}
				numberOfSymbols=0;
				StopMakingFile=0;
				AssembleFile();*/
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case SYMBOL:{
				/*
				ShowSymbolTable();*/
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case PROGADDR:{
				ProgaddrFunc();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
			}
			case LOADER:{
				LoadFunc();
				errorFlag = (errorFlag == 1) ? 0 : 0;
				break;
				
			}
			case RUN_:{
				//RunFunc();
				/*errorFlag = (errorFlag == 1) ? 0 : 0;*/
				break;
			}
			case DEBUG:{
				break;
				   }
			case BP:{
				break;
			}
			case INVALID:{ 
			printf("[ERROR] INVALID COMMAND OR TOO MANY ARGUMENTS!\n");
				break;;
			}
		}
			
	}
	return 0;
}

int GetCommandNumber(char *command)
{
	if(SAME_STR(inputUser,"help") || SAME_STR(inputUser,"h"))
		return 0;
	else if(SAME_STR(inputUser,"dir") || SAME_STR(inputUser,"d"))
		return 1;
	else if(SAME_STR(inputUser,"quit") || SAME_STR(inputUser,"q"))
		return 2;
	else if(SAME_STR(inputUser,"history") || SAME_STR(inputUser,"hi"))
		return 3;
	else if(SAME_STR(inputUser,"dump") || SAME_STR(inputUser,"du"))
		return 4;
	else if(SAME_STR(inputUser,"fill") || SAME_STR(inputUser,"f"))
		return 5;
	else if(SAME_STR(inputUser,"edit") || SAME_STR(inputUser,"e"))
		return 6;
	else if(SAME_STR(inputUser,"reset"))
		return 7;
	else if(SAME_STR(inputUser,"opcode"))
		return 8;
	else if(SAME_STR(inputUser,"opcodelist"))
		return 9;
	else if(SAME_STR(inputUser,"type"))
		return 10;
	else if(SAME_STR(inputUser,"assemble"))
		return 11;
	else if(SAME_STR(inputUser,"symbol"))
		return 12;
	else if(SAME_STR(inputUser,"progaddr"))
		return 13;
	else if(SAME_STR(inputUser,"loader"))
		return 14;
	else if(SAME_STR(inputUser,"run"))
		return 15;
	else if(SAME_STR(inputUser,"debug"))
		return 16;
	else if(SAME_STR(inputUser,"bp"))
		return 17;
	else
		return 18;
		
}

int GetHashTableAddress(char *s)
{
                  int i,sum;
                  int len=strlen(s);
                  for(i=0,sum=0; i< len; i++)
                  {
				       sum+=s[i];
				                    }
                  return sum%20;

}
void InitializeOpcodeTable()
{
	FILE *opcodeFileStream;
	int hashAddress;
	int inputMnemonic_;
	int i;
	char inputOpcodeArray[10];
	
	
	
	opcodeFileStream=fopen("opcode.txt","r");
	for(i=0;i<20;i++){
		opcodeHashTable[i]=NULL;			
		opcodeHashTableEnd[i]=NULL;			
	}
	while(feof(opcodeFileStream)==0)
	{
		fscanf(opcodeFileStream,"%2X%s",&inputMnemonic_,inputOpcodeArray);
		hashAddress=GetHashTableAddress(inputOpcodeArray);
		
		
		if(opcodeHashTable[hashAddress]==NULL){
			opcodeHashTableEnd[hashAddress]=(opcodeLinkedList*)malloc(sizeof(opcodeLinkedList));
			(*opcodeHashTableEnd[hashAddress]).codeNumber=inputMnemonic_;
			strcpy(opcodeHashTableEnd[hashAddress]->opcode,inputOpcodeArray);
			
			
			fscanf(opcodeFileStream,"%s",opcodeHashTableEnd[hashAddress]->format);
			opcodeHashTable[hashAddress]=opcodeHashTableEnd[hashAddress];
			opcodeHashTableEnd[hashAddress]->link=NULL;
		}
		else{
			opcodeHashTableEnd[hashAddress]->link=(opcodeLinkedList*)malloc(sizeof(opcodeLinkedList));
			opcodeHashTableEnd[hashAddress]=opcodeHashTableEnd[hashAddress]->link;
			(*opcodeHashTableEnd[hashAddress]).codeNumber=inputMnemonic_;
			strcpy(opcodeHashTableEnd[hashAddress]->opcode,inputOpcodeArray);
			
			
			fscanf(opcodeFileStream,"%s",opcodeHashTableEnd[hashAddress]->format);
			opcodeHashTableEnd[hashAddress]->link=NULL;
		}	
	}
	fclose(opcodeFileStream);
}


void quit()
{
	int i;
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	
	
	numberOfInputCommand--;
	
	inputCommand[numberOfInputCommand]='\0';
	for(i=0;i<=numberOfInputCommand;i++){
		if(inputCommand[i]!=' '&&inputCommand[i]!='\0'){
			errorFlag=1;
			break;
		}
	}
	

}
void FreeMemory()
{
	int i;
	while(headHistory!=NULL)
	{
		temporaryHead=headHistory;
		headHistory=headHistory->link;
		free(temporaryHead);
	}
	for(i=0;i<20;i++)
	{
		while(opcodeHashTable[i]!=NULL){
			temporaryOpcodeHashTable=opcodeHashTable[i];
			opcodeHashTable[i]=opcodeHashTable[i]->link;
			free(temporaryOpcodeHashTable);
		}
	}
	while(headSymbol!=NULL)
	{
		temporarySymbol=headSymbol;
		headSymbol=headSymbol->link;
		free(temporarySymbol);
	}
}

void Help()
{
	int i;
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	
	
	numberOfInputCommand--;
	inputCommand[numberOfInputCommand]='\0';
	for(i=0;i<=numberOfInputCommand;i++){
		if(inputCommand[i]!=' '&&inputCommand[i]!='\0'){
			errorFlag=1;
			break;;
		}
	}	
	//Contents to be saved to history.
	totalNumberOfInput=strcat(inputUser,inputCommand);
	
	if(errorFlag==0)
	{
		for(i=0; i<16;i++)
		{
			printf("%s\n",commandNamesHelp[i]);

		}
		PushToHistory();
	}
}
void PushToHistory()
{
	numberOfHistoryEntry++;
	if(numberOfHistoryEntry==1)
	{
		headHistory=(historyLinkedList*)malloc(sizeof(historyLinkedList));
		strcpy(headHistory->dataHistory,totalNumberOfInput);
		headHistory->link=NULL;
		tailHistory=headHistory;
	}
	else
	{
		tailHistory->link=(historyLinkedList*)malloc(sizeof(historyLinkedList));
		tailHistory=tailHistory->link;
		strcpy(tailHistory->dataHistory,totalNumberOfInput);
		tailHistory->link=NULL;
	}

}
void DirFunc()
{
	int i=0;
	DIR *directoryStream = NULL;
	struct dirent *directory = NULL;
					
	directoryStream=opendir(".");
	directory = readdir(directoryStream);
	
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	numberOfInputCommand--;
	inputCommand[numberOfInputCommand]='\0';
	for(i=0;i<=numberOfInputCommand;i++){
		if(inputCommand[i]!=' '&&inputCommand[i]!='\0'){
			errorFlag=1;
			break;;
		}
	}
	printf("error flag is: %d\n", errorFlag);
	if(errorFlag==0)
	{
		totalNumberOfInput=strcat(inputUser,inputCommand);
	
		for(;directory!=NULL;directory= readdir(directoryStream))
		{
			i++;
			struct stat directoryFile;
			if(stat((const char*)directory->d_name,&directoryFile)!=0)
				printf("File is not found\n");
			if((SAME_STR(directory->d_name,"."))|| (SAME_STR(directory->d_name,"..")))
			{
				i--;
				continue;
			}
			printf("%s", directory->d_name);
			if(S_ISDIR(directoryFile.st_mode))
				printf("/");
			if((directoryFile.st_mode & S_IXOTH) || (directoryFile.st_mode & S_IXGRP) || (directoryFile.st_mode & S_IXUSR))
				printf("*");
			printf("\t");
			if(i==3)
			{
				printf("\n");
				i=0;
			}

		}
		printf("\n");
		PushToHistory();	
	}
}

// histrace implementation functions
void History()
{
	int i,count_history;
	printf("until here is the code\n");
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	numberOfInputCommand--;
	inputCommand[numberOfInputCommand]='\0';
	for(i=0;i<=numberOfInputCommand;i++){
		if(inputCommand[i]!=' '&&inputCommand[i]!='\0'){
			errorFlag=1;
			break;;
		}
	}	
	if(errorFlag==0){
		totalNumberOfInput=strcat(inputUser,inputCommand);
		PushToHistory();	
		temporaryHead=headHistory;
		count_history=1;
		while(temporaryHead!=NULL){
			printf("%d	%s\n",count_history,temporaryHead->dataHistory);
			temporaryHead=temporaryHead->link;
			count_history++;
		}
	}
}

//initialize the virtual memory 
void InitializeMemory()
{
	size_t i = 0;
	virtualMemory.sizeOfMemory = 16*65536;
	virtualMemory.columnOfMemory = 65536;
	virtualMemory.rowOfMemory = 16;
	virtualMemory.minimumASCII = 0x20;
	virtualMemory.maximumASCII = 0x7E;
	virtualMemory.maximumByte = 0xFF;

	virtualMemory.Memory = (unsigned int**)malloc(sizeof(unsigned int**) * virtualMemory.columnOfMemory);

	for(i = 0; i != virtualMemory.columnOfMemory; ++i)
	{
		virtualMemory.Memory[i] = (unsigned int*)calloc(sizeof(unsigned int*), virtualMemory.rowOfMemory);
	}
}

void ReadArguments()
{
	char temporary;
	char command[20];
	
	cmdArgument = (cmdWithArgument*)malloc(sizeof(cmdWithArgument)*3);
		
	for (int i = 0; i < 3; ++i) 
	{
		cmdArgument[i].argument = malloc(sizeof(char)*40);
	}
	scanf("%c", &temporary);
	fgets(command,sizeof(command),stdin);
	GetArguments(command);
	return;
}
void FreeArguments()
{
	int i;
	
	for (i = 0; i < 3; ++i) 
		{
			free(cmdArgument[i].argument);
		}
		free(cmdArgument);
		dumpFlag=0;
	
	return;
}

void GetArguments(char *command)
{
	char *temp=NULL;
	char *temp2=NULL;
	char *savePtr=NULL;
	int count=0;

	temp2 = (char*)malloc(sizeof(char)*20);
	strcpy(temp2,command);
	temp = strtok_r(temp2," \t\n",&savePtr);
	strcpy(cmdArgument[count].argument,temp);
	count++;
	
	while(temp != NULL)
	{
		dumpFlag++;
		if(count == 4)
		{
			return;
		}
		temp = strtok_r(NULL," \t\n",&savePtr);

		if (temp) {
			strcpy(cmdArgument[count].argument,temp);
			count++;
		}
	}
	return;
}

int DumpMemory(char *start, char *end)
{
	int startInHexadecimal=0;
	int endInHexadecimal=0;
	
	
	IsStringEmpty(start)==1?
		startInHexadecimal = -1 : (startInHexadecimal = ConvertStringToHex(start));

	IsStringEmpty(end)==1?
		endInHexadecimal = -1 : (endInHexadecimal = ConvertStringToHex(end));
	
	if(startInHexadecimal == -1 && endInHexadecimal == -1)
		UntouchedDump();
	else if(startInHexadecimal >= 0 && endInHexadecimal == -1)
		DumpWithStartOnly(startInHexadecimal);
	else
		DumpWithStartEnd(startInHexadecimal, endInHexadecimal);
	
	return 0;
}

//executes when there are no provide arguments for dump command
int UntouchedDump()
{
	int start = last;
	int end = last + (0x10 * 10)-1;
	int result = 0;
	
	
	PrintMemoryContent(start, end);

	return result;
}

//executes when there is only start as an argument for dump command
int DumpWithStartOnly(int start)
{
	int end = start + (0x10 * 10)-1;
	int result = 0;

	if((start % 0x10) > 0)
		end -= 0x10;

	PrintMemoryContent(start, end);


	return result;
}

//executes when there both start and end argument are supplied
int DumpWithStartEnd(int start, int end)
{
	int result = 0;
	
	PrintMemoryContent(start, end);


	return result;
}

//prints the current content of the virtual memory
int PrintMemoryContent(int start, int end)
{
	size_t rowEnd = 0;
	size_t columnEnd = 0;
	
	size_t row = 0;
	size_t col = 0;

	size_t i = 0;
	size_t j = 0;


	if(start >= virtualMemory.sizeOfMemory)
		return 1;
	if(end >= virtualMemory.sizeOfMemory)
		return 1;
	if(start >= end)
		return 1;
	
	if(start < 0)
		return 1;
	if(end < 0)
		return 1;


	printf("Start %02X\n", start);
	printf("End %02X\n", end);

	if(start == 0)
	{
		col = 0;
		row = 0; 
		
	}
	
	else
	{
		col = start / 0x10;
		row = start % 0x10;
	}
	
	columnEnd = end / 0x10;
	rowEnd = end % 0x10;

	for(i=col; i <= columnEnd; ++i)
	{
		printf("%05X | ", (int)i * 0x10);
		for(j=0; j != 0x10; ++j)
		{
			if((col == (int)i) && (j < row))
			{
				printf("  ");
			}
			else if(((columnEnd) == (int)i) && (j > rowEnd))
			{
				printf("  ");
			}
			else
			{
				printf("%02X", virtualMemory.Memory[i][j]);
			}
			printf(" ");
		}
		printf("; ");


		for(j = 0; j != 0x10; ++j)
		{
			if((col == ((int)i)) && (j < row))
			{
				
				printf(".");
			}
			else if((columnEnd == (int)i) && (j > rowEnd))
			{
				printf(".");
			}
			else if(virtualMemory.Memory[i][j] >= virtualMemory.minimumASCII && 
					virtualMemory.Memory[i][j] <= virtualMemory.maximumASCII)
			{
				printf("%c", (char)virtualMemory.Memory[i][j]);
			}
			else
			{
				printf(".");
			}
		}
		printf("\n");
	}
	last = end+1;
	return 0;
}

//Returns 0 when a string is empty
int IsStringEmpty(char *str)
{
	if(SAME_STR(str, "empty"))
		return 1;

	return 0;
}

//converts string to hexadecimal
int ConvertStringToHex(char *str)
{
	
	int stringLength = strlen(str);
	
	int result = 0;
	
	
	if(stringLength >= 2)
	{
		result = ConvertCharToASCII(str[stringLength-1]);
		result += ConvertCharToASCII(str[stringLength-2])*0x10;
	}
	else if(stringLength == 1)
	{
		result = ConvertCharToASCII(str[0]);
	}
	else
		result = -1;

	return result;
}

//converts char to ASCII codes
int ConvertCharToASCII(char a)
{
	int result = 0;
	
	
	if(a >= 'A' && a <= 'F')
		result = a - 55;
	else if(a >= 'a' && a <= 'f')
		result = a - 87;
	else if(a >= '0' && a <= '9')
		result = a - 48;
	
	
	return result;
}


// Free memory allocation for virtual memory
void FreeMemoryDump()
{
	size_t i=0;
	for(i=0; i != virtualMemory.columnOfMemory; ++i)
		free(virtualMemory.Memory[i]);
	free(virtualMemory.Memory);
}

//Modifies first argument of any command for passing into other function
void ProcessDumpArgument()
{
	int i=0;
	int stringLength = 0;
	//char tempString[20];


	stringLength= strlen(cmdArgument[1].argument);

	for(i=0;i<stringLength;i++)
	{
		if(cmdArgument[1].argument[i] == ',')
		{
			cmdArgument[1].argument[i] = '\0';
			break;
		}
	}
}

//Modifies second argument of any command for passing into other function
void ProcessDumpArgument2()
{
	int i=0;
	int stringLength = 0;
//	char tempString[20];


	stringLength= strlen(cmdArgument[2].argument);

	for(i=0;i<stringLength;i++)
	{
		if(cmdArgument[2].argument[i] == ',')
		{
			cmdArgument[2].argument[i] = '\0';
			break;
		}
	}
	
}

//Edits memory content of vitual memory from a particular address
int EditMemoryContent(char *address, char *value)
{
	int addressInHex = 0;
	int valueInHex = 0;
	int col=0, row=0;
	if(IsStringEmpty(address))
		return 1;
	if(IsStringEmpty(value))
		return 1;

	addressInHex = ConvertStringToHex(address);
	valueInHex = ConvertStringToHex(value);
	
	row = addressInHex % 0x10;
	col = addressInHex / 0x10;
	

	virtualMemory.Memory[col][row] = valueInHex;
	return 0;
}

//Fill virtual memory from start address to end address with a certain value
int FillMemory(char *start, char *end, char *value)
{
	int startInHexadecimal = 0;
	int endInHexadecimal = 0;
	int valueInHex = 0;
	size_t start_col = 0;
	size_t start_row = 0;
	size_t columnEnd = 0;
	size_t rowEnd = 0;
	size_t i = 0, j = 0;

	// Verify, 1 is false
	if(IsStringEmpty(value))
		return 1;
	
	if(IsStringEmpty(start))
		return 1;
	
	if(IsStringEmpty(end))
		return 1;
	

	startInHexadecimal = ConvertStringToHex(start);
	endInHexadecimal = ConvertStringToHex(end);
	valueInHex = ConvertStringToHex(value);
	
	if(valueInHex < 0 || valueInHex > virtualMemory.maximumByte)
		return 1;
	if(startInHexadecimal >= endInHexadecimal)
		return 1;
	
	if(startInHexadecimal < 0 || startInHexadecimal >= virtualMemory.sizeOfMemory)
		return 1;
	if(endInHexadecimal < 0 || endInHexadecimal >= virtualMemory.sizeOfMemory)
		return 1;
	

	start_row = startInHexadecimal % 0x10;
	start_col = startInHexadecimal / 0x10;
	
	rowEnd = endInHexadecimal % 0x10;
	columnEnd = endInHexadecimal / 0x10;
	

	for(i=start_col; i <= columnEnd; ++i)
	{
		for(j=start_row; j != 0x10; ++j)
		{
			if((i == columnEnd) && (j > rowEnd))
				break;
			virtualMemory.Memory[i][j] = valueInHex;
		}
	}
	return 0;
}

// variable names of mnemonic and opcode are changed in this function.
void SearchPrintSpecificOpcode()
{
	int i,j;
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]==' ');
	
	
	numberOfInputCommand--;
	remember_start=numberOfInputCommand;
	errorFlag=0;
	numberOfInputCommand=remember_start+1;
	numberOfBlank=0;
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		if(inputCommand[numberOfInputCommand]==' ')
			numberOfBlank++;
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	numberOfInputCommand--;
	remember_comma=numberOfInputCommand;
	numberOfInput=0;
	if(remember_comma-remember_start+1>=8){
		errorFlag=1;
	}
	
	if(errorFlag==0)
	{
		inputCommand[remember_comma]='\0';
		for(i=remember_start;i<=remember_comma;i++)
		{
			opcode_input[numberOfInput]=inputCommand[i];
			numberOfInput++;
		}
		for(i=0;i<20;i++)
		{
			temporaryOpcodeHashTable=opcodeHashTable[i];
			while(temporaryOpcodeHashTable!=NULL){
				if(strlen(opcode_input)-numberOfBlank==strlen(temporaryOpcodeHashTable->opcode)){
					for(j=strlen(temporaryOpcodeHashTable->opcode);j<strlen(opcode_input);j++)
						opcode_input[j]='\0';
				}
				if(SAME_STR(temporaryOpcodeHashTable->opcode,opcode_input)){
					errorFlag=1;
					break;
				}
				temporaryOpcodeHashTable=temporaryOpcodeHashTable->link;
				errorFlag=0;
			}
			if(errorFlag==1){
				break;
			}
		}
		if(errorFlag==0){
			errorFlag=1;
		}
		else{
			errorFlag=0;
		}
		if(errorFlag==0)
		{
			printf("opcode is %2X\n",(*temporaryOpcodeHashTable).codeNumber);
			for(i=0;i<=9;i++)
				opcode_input[i]='\0';
			inputCommand[numberOfInputCommand]='\0';
			totalNumberOfInput=strcat(inputUser,inputCommand);
			PushToHistory();
		}
	}
}
void ShowSymbolTable(){
	int i;
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	numberOfInputCommand--;
	inputCommand[numberOfInputCommand]='\0';
	for(i=0;i<=numberOfInputCommand;i++){
		if(inputCommand[i]!=' '&&inputCommand[i]!='\0'){
			errorFlag=1;
			break;
		}
	}
	if(errorFlag==0){
		temporarySymbol=headSymbol;
		while(temporarySymbol!=NULL)
		{
			printf("\t%s\t%04X",temporarySymbol->nameSymbol,temporarySymbol->addressLocation);
			temporarySymbol=temporarySymbol->link;
			printf("\n");
		}
	}
}
void PrintOpcodeList()
{
	int i;
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]!='\n');
	
	numberOfInputCommand--;
	inputCommand[numberOfInputCommand]='\0';
	for(i=0;i<=numberOfInputCommand;i++){
		if(inputCommand[i]!=' '&&inputCommand[i]!='\0'){
			errorFlag=1;
			break;
		}
	}
	if(errorFlag==0){
		errorFlag=0;
		totalNumberOfInput=strcat(inputUser,inputCommand);
		for(i=0;i<20;i++){
			temporaryOpcodeHashTable=opcodeHashTable[i];
			printf("%d :",i);
			
			while(temporaryOpcodeHashTable!=NULL){
				printf(" [%s,%2X,%s] ",temporaryOpcodeHashTable->opcode,(*temporaryOpcodeHashTable).codeNumber,temporaryOpcodeHashTable->format);
				temporaryOpcodeHashTable=temporaryOpcodeHashTable->link;
				if(temporaryOpcodeHashTable!=NULL)
					printf("->");
			}
			printf("\n");
		}
		PushToHistory();	
	}


}

void ReadFileContent(){
	FILE *directory_file;
    char file_name[20];
	char test[100];
	ReadFileWithFilename(file_name);
	if(errorFlag==0){
		directory_file=fopen(file_name,"r");
		if(directory_file==NULL)
			errorFlag=1;
		if(errorFlag==0){
			while(fgets(test,sizeof(test),directory_file)!=NULL)
			{
				printf("%s",test);					
			}
			fclose(directory_file);
		}
	}
}
void ReadFileWithFilename(char *only_filename)
{
	int i;
	int count_of_filename=0;
	// Start reading the first input value
	numberOfInputCommand=0;
	ReadWhiteSpace();
	// Remember input start position
	remember_start=numberOfInputCommand-1;
	// Enter is not able to enter name
	if(inputCommand[remember_start]=='\n')
		errorFlag=1;
	else{
		numberOfInputCommand=remember_start+1;
		do{
			scanf("%c",&inputCommand[numberOfInputCommand]);
			numberOfInputCommand++;
		}while(inputCommand[numberOfInputCommand-1]!='\n'&&inputCommand[numberOfInputCommand-1]!=' ');
		remember_end=numberOfInputCommand-1;
		if(inputCommand[remember_end]==' '){
			numberOfInputCommand=remember_end+1;
			ReadWhiteSpace();
			if(inputCommand[numberOfInputCommand-1]!='\n')
				errorFlag=1;
		}
		if(errorFlag==0){
			
			for(i=remember_start;i<remember_end;i++){
				only_filename[count_of_filename]=inputCommand[i];
				count_of_filename++;
			}
			only_filename[count_of_filename]='\0';
		}
	}
}
void ReadWhiteSpace(){
	do{
		scanf("%c",&inputCommand[numberOfInputCommand]);
		numberOfInputCommand++;
	}while(inputCommand[numberOfInputCommand-1]==' ');
}


void ProgaddrFunc()
{
	char inputUser[20];
	char space;
	int inputLength;
	int i=0;
	int addr=-1;

	progAddr=0;
	scanf("%c", &space);
	
	fgets(inputUser,sizeof(inputUser)-1,stdin);
	inputLength= strlen(inputUser);
	inputUser[inputLength-1]='\0';

	//analysis command
	while(inputUser[i]!='\0')
	    {
			if(IsHexadecimal(inputUser[i]))
			{
				if(addr==-1)
					addr=ToHexadecimal(inputUser[i]);
				else
					addr=addr*16+ToHexadecimal(inputUser[i]);
			}
			//wrong input 2 : there is wrong command
			else
			{
				printf("[ERROR] WRONG INPUT\n");
				errorFlag=1;
				return;
			}
			i++;
		}

	progAddr=addr;
	return;
}

int IsHexadecimal(char c)
{
//	printf("char is %c\n", c);
	if(c>='0' && c<='9')
		return 1;
	else if(c>='a' && c<='f')
		return 1;
	else if(c>='A' && c<='F')
		return 1;
	
	return 0;
}

int ToHexadecimal(char c)
{
	if(c>='0' && c<='9')
		return c-'0';
	
	switch(c)
	{
		case 'A' : return 10; 
		case 'B' : return 11;
		case 'C' : return 12;
		case 'D' : return 13;
		case 'E' : return 14;
		case 'F' : return 15;

		case 'a' : return 10;
		case 'b' : return 11;
		case 'c' : return 12;
		case 'd' : return 13;
		case 'e' : return 14;
		case 'f' : return 15;

	}
	return -1;
}

//link and load (pass1, pass2)
void LoadFunc() 
{
	char inputUser[100];
	char space;
	char* pch;
	char tmp[LENGTH_OF_INPUT];
	char filename[50][100]; 
	int j;
	int numberOfFiles;
	
	scanf("%c", &space);
	
	fgets(inputUser,sizeof(inputUser),stdin);
	numberOfFiles=0;

	strcpy(tmp,(char*)inputUser);
	j=0;
	pch=strtok(tmp," \n");
	strcpy(filename[j],pch);
	j++;

	while((pch=strtok(NULL," \n"))!=NULL)
	{

		strcpy(filename[j++],pch);
	}
	numberOfFiles=j;
	
	LoadFile(filename,numberOfFiles);

	return;
}


void LoadFile(char filename[50][100],int n)
{
	FILE* fileStream[50];
	
	int i,j,k;
	int constrolSectionLength_=0;
	int length;
	int tempAddress;
	char address[7];
	char name[7];
	char lengthArray[7];
	char stream[MAXIMUM_LENGTH];
	
	externalSymbolLinkedList* tmp;
	
	
	externalSymbolTable=NULL;
	controlSectionAddress=progAddr;
	
	//check all the file
	for(i=0;i<n;i++)
	{		
		controlSectionAddress+=constrolSectionLength_;
		fileStream[i]=fopen(filename[i],"r");

		fgets(stream,sizeof(stream),fileStream[i]);
		
		
		//read control section,length
		strncpy(name,&stream[1],6);
		strncpy(lengthArray,&stream[13],6);
		strncpy(address,&stream[7],6);
		for(j=5;j>=0;j--)
		{
			if(name[j]!=' ')
				break;
		}
		name[j+1]='\0';

		
		length=LoadConvertCharToHexa(lengthArray);
		tempAddress=LoadConvertCharToHexa(address);
		tempAddress+=controlSectionAddress;
		constrolSectionLength_=length;
		tmp=(externalSymbolLinkedList*)malloc(sizeof(externalSymbolLinkedList));
		strcpy(tmp->nameSymbol,"\0");
		strcpy(tmp->partOfControlSection,name);
		tmp->length=length;
		tmp->loadAddress=tempAddress;
		tmp->link=NULL;

		//add new external symbol table
		if(!IsPresentInExternalTable(tmp))
		{
			AddToExternalTable(tmp);
			
		}
		else
		{
			printf("[ERROR] CONTROL SECTION ALREADY EXISTING\n");
			errorFlag=1;
			return;
		}

		//check object code and add new external symbol table
		while(fgets(stream,sizeof(stream),fileStream[i])!=NULL)
		{		
			if(stream[0]=='D')
			{
				for(j=1;j<strlen(stream)-1;j=j+12)
				{

					strncpy(name,&stream[j],6);
					strncpy(lengthArray,&stream[j+6],6);
			
					for(k=5;k>=0;k--)
					{
						if(name[k]!=' ')
						break;
					}
					name[k+1]='\0';

					length=LoadConvertCharToHexa(lengthArray);
		
					tmp=(externalSymbolLinkedList*)malloc(sizeof(externalSymbolLinkedList));
					strcpy(tmp->partOfControlSection,"\0");
					strcpy(tmp->nameSymbol,name);
					
					
					tmp->length=-1;
					tmp->loadAddress=length;
					tmp->loadAddress+=controlSectionAddress;
					tmp->link=NULL;
			
					if(!IsPresentInExternalTable(tmp))
					{
						AddToExternalTable(tmp);
					}
					else
					{
						printf("[ERROR] : THE SYMBOL IS ALREADY INSIDE SYMBOL TABLE\n");
						errorFlag=1;
						return;
					}
					
				}
			}
	
		}
	}

	
	ShowExternalTable();

	
	Pass2AlgorithmLoad(filename,n);
	
	return; 
					
}

int LoadConvertCharToHexa(char* num)
{
	int temporaryNumber=0;
	int i=0;
	
	while(num[i]!='\0')
	{
		if(IsHexadecimal(num[i]))
		{
			if(i==0)
				temporaryNumber=ToHexadecimal(num[i]);
			else
				temporaryNumber=temporaryNumber*16+(ToHexadecimal(num[i]));
		}
		else
			return -1; 
		i++;
	}
	return temporaryNumber;

}

int IsPresentInExternalTable(externalSymbolLinkedList* sym)
{
	externalSymbolLinkedList* tmp;
	tmp=externalSymbolTable;
	while(tmp)
	{
		if(sym->nameSymbol[0]=='\0')
		{
			if(SAME_STR(tmp->partOfControlSection,sym->partOfControlSection))
				return 1;
		}
		else if(sym->partOfControlSection[0]=='\0')
		{
			if(SAME_STR(tmp->nameSymbol,sym->nameSymbol))
				return 1;	
		}
			tmp=tmp->link;
	}
	return 0;
}

void AddToExternalTable(externalSymbolLinkedList* sym)
{
		externalSymbolLinkedList* temporary;
		externalSymbolLinkedList* previous;
		externalSymbolLinkedList *after;
			
		if(IsPresentInExternalTable(sym))
		{
			errorFlag=1;
			return;
		}

		//init the symbol table		
		if(externalSymbolTable==NULL)
		{
			temporary=(externalSymbolLinkedList*)malloc(sizeof(externalSymbolLinkedList));
			strcpy(temporary->nameSymbol,sym->nameSymbol);
			strcpy(temporary->partOfControlSection,sym->partOfControlSection);
			
			
			temporary->loadAddress=sym->loadAddress;
			temporary->length=sym->length;
			
			temporary->link=NULL;
			
			
			externalSymbolTable=temporary;
		}
				
		else
		{
			after=previous=externalSymbolTable;

			temporary=(externalSymbolLinkedList*)malloc(sizeof(externalSymbolLinkedList));
			strcpy(temporary->partOfControlSection,sym->partOfControlSection);
			strcpy(temporary->nameSymbol,sym->nameSymbol);
			
			temporary->loadAddress=sym->loadAddress;
			temporary->length=sym->length;
			
			temporary->link=NULL;

			while(after!=NULL)
			{
				previous=after;
				after=after->link;
			}
			previous->link=temporary;	


		}
		return ;
}

void ShowExternalTable()
{
	externalSymbolLinkedList* temporaryExternalTable;
	int length=0;
	temporaryExternalTable=externalSymbolTable;
	
	
	printf("	control   symbol   address   length\n");
	printf("	section   name\n");
	printf("	--------------------------------------\n");
	
	
	while(temporaryExternalTable)
	{
		if(temporaryExternalTable->partOfControlSection[0]=='\0')
			printf("	           %-6s    %04X\n",temporaryExternalTable->nameSymbol,temporaryExternalTable->loadAddress);
		else if(temporaryExternalTable->nameSymbol[0]=='\0')
		{
			printf("	%-6s               %04X      %04X\n",temporaryExternalTable->partOfControlSection,temporaryExternalTable->loadAddress,temporaryExternalTable->length);
			length+=temporaryExternalTable->length;
		}
		
		temporaryExternalTable=temporaryExternalTable->link;

	}
	printf("	--------------------------------------\n");
	printf("                          total length  %04X\n",length);
	totalLength=length;
}

externalSymbolLinkedList searchEXS(char* name)
{
	externalSymbolLinkedList* temporaryExternalTable;
	
	
	temporaryExternalTable=externalSymbolTable;
	while(temporaryExternalTable)
	{
		if(SAME_STR(temporaryExternalTable->partOfControlSection,name) && temporaryExternalTable->partOfControlSection[0]!='\0' )
			return *temporaryExternalTable;
		
		else if(SAME_STR(temporaryExternalTable->nameSymbol,name) && temporaryExternalTable->nameSymbol[0]!='\0')
			return *temporaryExternalTable;
		temporaryExternalTable=temporaryExternalTable->link;
	}
	
	return *temporaryExternalTable;
}

void Pass2AlgorithmLoad(char filename[50][100],int n)
{
	int refNum[MAXIMUM_LENGTH];
	int m;
	int i;
	int j;
	int l,index;
	int len,address;
	int executionAddress;
	int lengthValue;
	int value,spAddress;
	char stream[MAXIMUM_LENGTH];
	char temporary[MAXIMUM_LENGTH];
	FILE* fileStream[50];
	
	long long x;
	
	externalSymbolLinkedList t;

	controlSectionAddress=progAddr;
	executionAddress=progAddr;

	//check all files
	for(i=0;i<n;i++)
	{
		fileStream[i]=fopen(filename[i],"r");
		j=0;

		fgets(stream,sizeof(stream),fileStream[i]);
		strncpy(temporary,&stream[1],6);
		
		for(j=5;j>=0;j--)
		{
			if(temporary[j]!=' ')
				break;
		}
		temporary[j+1]='\0';
		t=searchEXS(temporary);
		executionAddress=t.loadAddress;

		refNum[1]=t.loadAddress;
				
		//check object codes
		while(fgets(stream,sizeof(stream),fileStream[i])!=NULL)
		{
		//text partition
			if(stream[0]=='T')
			{
				strncpy(temporary,&stream[1],sizeof(char)*6);
				temporary[6]='\0';
		
				spAddress=LoadConvertCharToHexa(temporary);
				spAddress+=executionAddress;

				strncpy(temporary,&stream[7],sizeof(char)*2);
				temporary[2]='\0';
				lengthValue=LoadConvertCharToHexa(temporary);
				
				for(j=0;j<lengthValue*2;j+=2)
				{
					strncpy(temporary,&stream[9+j],sizeof(char)*2);
					value=LoadConvertCharToHexa(temporary);
					memoryLoad[spAddress++]=value;
				}
			}
		
			else if(stream[0]=='R')//reference partition
			{
				for(l=1;l<strlen(stream);l+=8)
				{
					strncpy(temporary,&stream[l],2);
					temporary[2]='\0';	
					index=LoadConvertCharToHexa(temporary);
					
					
					strncpy(temporary,&stream[l+2],6);
					for(j=0;j<5;j++)
					{
						if(temporary[j]==' ' || temporary[j]=='\n')
							break;
					}
					temporary[j]='\0';
					t=searchEXS(temporary);
					refNum[index]=t.loadAddress;
				}
			}
			//modification partition
			else if(stream[0]=='M')
			{
				strncpy(temporary,&stream[1],6);
				temporary[6]='\0';
				address=LoadConvertCharToHexa(temporary);
				address+=executionAddress;
				
				strncpy(temporary,&stream[7],2);
				temporary[2]='\0';
				len=LoadConvertCharToHexa(temporary);
				
				x=memoryLoad[address];
				for(m=1;m<=(1+len)/2-1;m++)
				{
					x=x<<8;
					x=x|memoryLoad[address+m];		
				}
				if(stream[9]=='+')
				{
					strncpy(temporary,&stream[10],2);
					temporary[2]='\0';
					index=LoadConvertCharToHexa(temporary);
					x+=refNum[index];
				}
				else if(stream[9]=='-')
				{
					strncpy(temporary,&stream[10],2);
					temporary[2]='\0';
					index=LoadConvertCharToHexa(temporary);
					x-=refNum[index];
				}

				//loading x into memory
				for(m=(1+len)/2-1; m>=0; m--)
				{		
						memoryLoad[address+m]=x&255;
						x=x>>8;
				}
	

			}

		}
	}
}


