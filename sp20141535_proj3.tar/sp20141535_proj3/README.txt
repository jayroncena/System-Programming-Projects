How to compile
1. >makefile {press enter}
2. >./20141535.out {press enter to execute the program}

