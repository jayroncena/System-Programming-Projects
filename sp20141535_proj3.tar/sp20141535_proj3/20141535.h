#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<dirent.h>
#include<sys/stat.h>

#define IMMEDIATE 1
#define INDIRECT 2
#define SIMPLE 3

#define A 0
#define X 1
#define L 2
#define B 3
#define S 4
#define T 5
#define F 6
#define PC 8
#define SW 9

#define SAME_STR(s1,s2) (strcmp(s1,s2)==0)
#define EMPTY -1
#define LENGTH_OF_INPUT 100
#define MAXIMUM_LENGTH 500

unsigned char memoryLoad[1048576];

//**************************************************
//**************************************************
//			PROJECT 1
//**************************************************
//**************************************************


//==================================================
//COMMAND PROCESSING VARIABLES
//==================================================

const char *shellStartCommand = "sicsim> ";
int numberOfInputCommand;
char *totalNumberOfInput;

enum commandEnum{
	HELP, 
	DIR_, 
	QUIT, 
	HISTORY, 
	DUMP, 
	FILL, 
	EDIT, 
	RESET, 
	OPCODE,
	OPCODELIST, 
	TYPE, 
	ASSEMBLE, 
	SYMBOL, 
	PROGADDR, 
	LOADER,
	RUN_, 
	DEBUG,
	BP, 
	INVALID} ;
int GetCommandNumber(char *command);
char inputCommand[60];

//====================================================
// HELP COMMAND FUNCTION
//====================================================
void Help();
// array of string commands for help command
char *commandNamesHelp[] = {"h[elp]","d[ir]","q[uit]","hi[story]","du[mp] [start, end]",
"e[dit address, value]","f[ill] start, end, value","reset","opcode mnemonic","opcodelist",
"assemble filename", "type filename", "symbol", "progaddr [address]", "loader [object filename1] [object filename2] […]",
"run", "debug", "bp [address]" };

//====================================================
// DIRECTORY COMMAND FUNCTION
//====================================================
void DirFunc();

//====================================================
// HISTORY COMMAND FUNCTION
//====================================================

void History();
//linked list for command history
typedef struct node
{
	char dataHistory[20];
	struct node *link;	
}historyLinkedList;

//pointer to history linked list
historyLinkedList *headHistory=NULL;
historyLinkedList *tailHistory;
historyLinkedList *temporaryHead;

void PushToHistory();//입력한 입력 스트링을 히스토리 링크드리스트에 저장

int numberOfHistoryEntry=0;
int numberOfInput;
int numberOfBlank=0;//루프나 주소 갯수를 세어주는 카운트 변수들


//=============================================================
//MEMORY MANAGEMENT-RELATED VARIABLES, STRUCTURES AND FUNCTIONS
//=============================================================

//Initialize Virtual Memory
void InitializeMemory();
// structure to implement virtual memory.
struct virtualMemory_
{
	unsigned int **Memory;
	size_t sizeOfMemory;
	size_t columnOfMemory;
	size_t rowOfMemory;
	size_t minimumASCII;
	size_t maximumASCII;
	size_t maximumByte;
	
	
}virtualMemory;
int last = 0;

// free virtual memory
void FreeMemoryDump();

//modify first argument of any command for passing
void ProcessDumpArgument();

//modfiy second argument of any command for passing
void ProcessDumpArgument2();


void FreeMemory();//quit시 메모리 할당 해주는 함수



//=============================================================
//DUMP COMMAND-RELATED VARIABLES, STRUCTURES AND FUNCTIONS
//==============================================================
// structure to save the arguments of those command with arguments
typedef struct
{
	char* argument;
}cmdWithArgument;

// pointer to command arguments
cmdWithArgument *cmdArgument;
int dumpFlag=0;
void GetArguments(char *command);
void FreeArguments();
void ReadArguments();

// main dump function
int DumpMemory(char *start, char *end);

//dump without 2 arguments
int UntouchedDump();
//dump function with only start as an argument
int DumpWithStartOnly(int start);
//dump function with both start and end arguments
int DumpWithStartEnd(int start, int end);
// prints the current state of virtual memory
int PrintMemoryContent(int start, int end);// print
//checks if a string is empty
int IsStringEmpty(char *str);
///convert string to hexadecimal
int ConvertStringToHex(char *str);
//change character tp ASCII
int ConvertCharToASCII(char a);

//=============================================================
//EDIT COMMAND-RELATED  FUNCTION
//==============================================================
int EditMemoryContent(char *address, char *value);

//=============================================================
//FILL COMMAND-RELATED  FUNCTION
//==============================================================
int FillMemory(char *start, char *end, char *value);

//=============================================================
//OPCODE COMMAND-RELATED  VARIABLES, STRUCTURES. FUNCTION
//==============================================================
// structure to save opcode's information
typedef struct opcode{//opcode hash table 구조체
	int codeNumber;
	char opcode[10];
	char format[10];
	struct opcode *link;
}opcodeLinkedList;

// pointer to opcode hash table	
opcodeLinkedList *opcodeHashTable[20];
opcodeLinkedList *opcodeHashTableEnd[20];
opcodeLinkedList *temporaryOpcodeHashTable;

//Initialize OPCODE table
void InitializeOpcodeTable();
int GetHashTableAddress(char *s);
void ResetData();
void SearchPrintSpecificOpcode();
void PrintOpcodeList();
void SearchOpcode(char *codeNumber,char *save_format,int *save_opocde,int *found_flag);

int remember_start;
int remember_comma;
int remember_end;

//==============================================================
//TYPE COMMAND RELATED FUNCTION
//===============================================================
void ReadFileContent();//현 디렉토리 내 파일을 읽어 내용을 출력해주는 함수
void ReadWhiteSpace();
void ReadFileWithFilename(char *only_filename);//filename을 입력받아 읽어오는 함수


//**************************************************
//**************************************************
//			PROJECT 2
//**************************************************
//**************************************************

//==============================================================
//SYMBOL COMMAND-RELATED VARIABLES, STRUCTURES, FUNCTIONS
//==============================================================
void ShowSymbolTable();

typedef struct symbol
{
	char nameSymbol[10];
	int addressLocation;
	struct symbol *link;
}symbolLinkedList;

symbolLinkedList *headSymbol=NULL;
symbolLinkedList *tailSymbol;
symbolLinkedList *temporarySymbol;

int numberOfSymbols;

void AddToSymbolTable(char (*read_line)[70],int location_count);
int FindOperandFromSymbolTable(char *purpose);


//==============================================================
//ASSEMBLE COMMAND-RELATED VARIABLES, STRUCTURES, FUNCTIONS
//==============================================================

void AssembleFile();
//Start address store variable
int startLocationAddress;
int lengthOfCode;
int baseAddress=-1;
int lengthOfTestRecord=0;
char baseOperand[20];
int modifyFlag=0;
int StopMakingFile=0;
int errorFlag=0;

int address;
// Calculate the input value and assign it to here.
int calculatedValue;

//Variable assignment variable for each input value
int numberValue;

char inputUser[20],opcode_input[10];

//divides whole user input for text record
void DivideWholeInput(char (*read_line)[70],int *divide_count,char *test);
//dividdes second input for text record
void DivideWholeInput2(char (*read_line)[70],int *divide_count,char *test);
//location of the first cpunter
void CalculateFirstLocationCounter(char *codeNumber,int *location_count);
//location of second counter
void CalculateSecondLocationCounter(char *codeNumber,char *purpose,int *location_count);
//calculate location of counter
void CalculateLocationCounter(char *codeNumber,char *save_format,int *location_count);
//calculate the total number of objects
void CalculateTotalObject(int *object_total,int object_front,int object_middle,int object_end);
//calculate total object considering format 4
void CalculateTotalObjectFormat4(int *object_total,int object_front,int object_middle,int object_end);
void CalculateFirstObject(char *codeNumber,int *object_code,int location_count);
void CalculateSecondObject(char *codeNumber,char *purpose,int *object_code,int location_count);
int CalculateFormat4(char *purpose,int save_opcode,int location_count);
void AssembleFirstPassTestRecord(FILE *imediate_file,char *address,int lengthOfTestRecord);
int ReturnTotalObjects(int loc_of_symbol,int location_count,int object_front);
int ReturnTotalObjectsWithFormat4(int loc_of_symbol,int location_count,int object_front);
void AssemblePassTwoFinalObject(FILE *object_file,FILE *imediate_file,FILE *modification_file,char *object_file_name);
int CalculateObject(char *purpose,char *save_format,int save_opcode,int location_count);
int CalculateObjectWithFormat4(char *purpose,int save_opcode);

FILE *assemble_file;// File variable to read the file in the current directory
FILE *imediate_file;// Files for intermediate course writing
FILE *listing_file;// for creating listing file
FILE *object_file;// for creating object files
FILE *modification_file;// modification Temporary file for saving
//===============================================================
// QUIT FUNCTION
//================================================================
void quit();

//===============================================================================
// UTILITY FUNCTIONS SUCH AS CONVERSION, CHARACTER REMOVAL ,WHITE SPACE REMOVAL ETC.
//===============================================================================

void ConvertStringToInteger(char *purpose,int *char_to_int);
void ConvertStringToIntegerBytes(char *purpose,int *char_to_int);
void RemoveEnterSymbol(char *test_copy);
int ObjectConvertStringToIntegerByte(char *purpose);
int ConvertStringToHexadecimal(char bit_16);
int ConvertStringToHexadecimalTotal(char *address);
int GetNumberOfRegisters(char reg);
int GetIndex(char *purpose);
void GetEndOfByteAsString(char *purpose,char *return_BYTE_string);
void ConverCharToString(char one_char,char *ASCII_string);
int IsHexadecimal(char c);
int ToHexadecimal(char c);
void TestForComma(char *test);
int GetBaseAddress();
void RemovePlusSymbol(char *codeNumber,char *mnemonic_plus);
void RemovePeriodSymbol(char *file_name,char *file_name_no_dot);
void RemoveIndex(char *purpose,char *purpose_delete);
void RemoveFormat(char *save_format);
int LoadConvertCharToHexa(char* num);

//**************************************************
//**************************************************
//			PROJECT 3
//**************************************************
//**************************************************

//============================================================================
//PROGADDR VARIABLES AND FUNCTIONS
//=============================================================================
void ProgaddrFunc();
int progAddr=0;

//===========================================================================
//LOAD-COMMAND RELATED FUNCTION VARIABLES AND STRUCTURES
//==========================================================================

//start loading function
void LoadFunc();

//pass algorithm for load
void LoadFile(char filename[50][100],int n);

//structure for external symbol table linked list
typedef struct externalSymbol
{
	int loadAddress;
	int length;
	char partOfControlSection[50];
	char nameSymbol[50];
	char temporaryChar;
	struct externalSymbol* link;
}externalSymbolLinkedList;

int IsPresentInExternalTable(externalSymbolLinkedList* sym);
void AddToExternalTable(externalSymbolLinkedList* sym);
void ShowExternalTable();

//Pass 2 algorithm for load
void Pass2AlgorithmLoad(char filename[50][100],int n);
externalSymbolLinkedList searchEXS(char* name);

externalSymbolLinkedList* externalSymbolTable;

int controlSectionAddress;
int totalLength;
