#include "20141535.h"

// get the command from user input
int GetCommand(char *command);

// push a node into history linked list
void Push(char* commandString);

//count the number wrong command
int noErrorCommand = 0;

//saves the last dump
int last = 0;

//counts number of arguments supplied for dump command
int dumpFlag = 0;

int main(void)
{
	int i=0;
	int k;
	
	char command[20];// input of the user
	int commandInt;//corresponding command number for different cases
	int flag=0;// saves status of dump command
	
	//int check=0;

	InitializeMemory(); //initialize the virtual memory
	InitializeOpcode(); // makes the opcode hash table
	

	while(1)
	{
		noErrorCommand = 0;	
		
		// allocate memory for command arguments
		cmdArgument = (cmdWithArgument*)malloc(sizeof(cmdWithArgument)*4);
		
		for (i = 0; i < 4; ++i) 
		{
			cmdArgument[i].argument = malloc(sizeof(char)*40);
		}
		
		printf("%s", shellStartCommand);
		
		fgets(command,sizeof(command)-1,stdin); //get user input
		commandInt= GetCommand(command); // get corresponfing command number


		if(commandInt != 10)
		{
			switch(commandInt)
			{

			case 0:{
					Help();
					break;
				}
			case 1:{
					Dir();
					break;
				}
			case 2:{
					printf("EXITING PROGRAM\n");
					FreeMemory();
					return 0;
				}
			case 3:{
						Push(command);
						noErrorCommand = 1;
						i=1;
						node_t *temp;
						temp = historyList;
						while(temp != NULL)
						{
							printf("%d %s", i, temp->commandString);
							i++;
							temp=temp->next;
						}
						break;
					}
			case 4:{
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							flag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							flag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else
						{
							ProcessDumpArgument();
							flag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
							dumpFlag=0;
							if(flag)
								return 0;
						}												
						break;
					}
			case 5:{
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							flag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							printf("MUST ENTER ADDRESS AND VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							flag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							printf("MUST ENTER VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else
						{
							ProcessDumpArgument();
							flag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							if(flag)
								return 0;
						}		
						break;
					}
			case 6:{
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							strcpy(cmdArgument[3].argument,"empty");
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("MUST ENTER START, END AND VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							strcpy(cmdArgument[3].argument,"empty");
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("MUST ENTER END AND VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==3)
						{
							ProcessDumpArgument();
							strcpy(cmdArgument[3].argument,"empty");
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("MUST ENTER VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else
						{
							ProcessDumpArgument();
							ProcessDumpArgument2();
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							if(flag)
								return 0;
						}		
						break;
						
					}
			case 7:{
				       for(i=0; i != virtualMemory.columnOfMemory; ++i)
					       for(k=0; k!= virtualMemory.rowOfMemory;++k)
						       virtualMemory.Memory[i][k] = 0;
				       break;
				}
			case 8:{
					SearchPrintSpecificOpcode(command);
					break;
				}	
			case 9:{
					PrintOpcodeList();
					break;
					}
			}
		}
		else
		{
			printf("INVALID COMMAND or TOO MANY ARGUMENTS \n");
			noErrorCommand = 1;
		}		
		if(noErrorCommand == 0)
		{
			Push(command);
		}
	
	//free memory allocation
		for (i = 0; i < 4; ++i) 
		{
			free(cmdArgument[i].argument);
		}
		free(cmdArgument);
		dumpFlag=0;
	}
	FreeMemory();
	return 0;
}

// get the command that user wants by tokenizing the whole string into different arguments
int GetCommand(char *command)
{
	char *temp=NULL;
	char *temp2=NULL;
	char *savePtr=NULL;
	int count=0;
	int i;

	temp2 = (char*)malloc(sizeof(char)*20);
	strcpy(temp2,command);
	temp = strtok_r(temp2," \t\n",&savePtr);
	strcpy(cmdArgument[count].argument,temp);
	count++;
	
	while(temp != NULL)
	{
		dumpFlag++;
		if(count == 5)
		{
			return 10;
		}
		temp = strtok_r(NULL," \t\n",&savePtr);

		if (temp) {
			strcpy(cmdArgument[count].argument,temp);
			count++;
		}
	}


	for(i=0;i<=10;i++)
	{
		if(i==10)
		{
			return 10;
		}
		if((strcmp(cmdArgument[0].argument,commandNames[i]))== 0 || (strcmp(cmdArgument[0].argument, altCommandNames[i])) == 0 )
		{
			return i;
		}
	}
	return 0;
}

//Prints all the kind of commands the user can input
void Help()
{
	int i;
	
	for(i=0; i<9;i++)
	{
		printf("%s\n",commandNamesHelp[i]);

	}
}

//Prints directories under current diretory and files below it
void Dir()
{
	int i=0;
	DIR *directoryStream = NULL;
	struct dirent *directory = NULL;
					
	directoryStream=opendir(".");
	directory = readdir(directoryStream);
					
	for(;directory!=NULL;directory= readdir(directoryStream))
	{
		i++;
		struct stat directoryFile;
		if(stat((const char*)directory->d_name,&directoryFile)!=0)
			printf("File is not found\n");
		if((strcmp(directory->d_name,"."))==0 || (strcmp(directory->d_name,".."))==0)
		{
			i--;
			continue;
		}
		printf("%s", directory->d_name);
		if(S_ISDIR(directoryFile.st_mode))
			printf("/");
		if((directoryFile.st_mode & S_IXOTH) || (directoryFile.st_mode & S_IXGRP) || (directoryFile.st_mode & S_IXUSR))
			printf("*");
		printf("\t");
		if(i==3)
		{
			printf("\n");
			i=0;
		}

	}
	printf("\n");
	closedir(directoryStream);
}

//store the whole input from user to the linked list
void Push(char* commandString)
{
	node_t* tempA;
	node_t* tempB;

	
	if(!historyList)
	{
		historyList = (node_t*)malloc(sizeof(node_t));
		strcpy((char*)(historyList->commandString),(char*)commandString);
		historyList->next=NULL;
	}
	
	else
	{
		tempA=tempB=historyList;
		tempB=tempB->next;

		while(tempB)
		{
			tempA=tempB;
			tempB=tempB->next;
		}

		tempA->next = (node_t*)malloc(sizeof(node_t));
		
		tempA=tempA->next;

		strcpy((char*)tempA->commandString,(char*) commandString);
		tempA->next=NULL;
	}

	return;
}

// dump virtual memory from the start to end
int DumpMemory(char *start, char *end)
{
	int startInHexadecimal=0;
	int endInHexadecimal=0;
	
	
	IsStringEmpty(start)==1?
		startInHexadecimal = -1 : (startInHexadecimal = ConvertStringToHex(start));

	IsStringEmpty(end)==1?
		endInHexadecimal = -1 : (endInHexadecimal = ConvertStringToHex(end));
	
	if(startInHexadecimal == -1 && endInHexadecimal == -1)
		UntouchedDump();
	else if(startInHexadecimal >= 0 && endInHexadecimal == -1)
		DumpWithStartOnly(startInHexadecimal);
	else
		DumpWithStartEnd(startInHexadecimal, endInHexadecimal);
	
	return 0;
}

//executes when there are no provide arguments for dump command
int UntouchedDump()
{
	int start = last;
	int end = last + (0x10 * 10)-1;
	int result = 0;
	
	
	PrintMemoryContent(start, end);

	return result;
}

//executes when there is only start as an argument for dump command
int DumpWithStartOnly(int start)
{
	int end = start + (0x10 * 10)-1;
	int result = 0;

	if((start % 0x10) > 0)
		end -= 0x10;

	PrintMemoryContent(start, end);


	return result;
}

//executes when there both start and end argument are supplied
int DumpWithStartEnd(int start, int end)
{
	int result = 0;
	
	PrintMemoryContent(start, end);


	return result;
}

//prints the current content of the virtual memory
int PrintMemoryContent(int start, int end)
{
	size_t rowEnd = 0;
	size_t columnEnd = 0;
	
	size_t row = 0;
	size_t col = 0;

	size_t i = 0;
	size_t j = 0;


	if(start >= virtualMemory.sizeOfMemory)
		return 1;
	if(end >= virtualMemory.sizeOfMemory)
		return 1;
	if(start >= end)
		return 1;
	
	if(start < 0)
		return 1;
	if(end < 0)
		return 1;


	printf("Start %02X\n", start);
	printf("End %02X\n", end);

	if(start == 0)
	{
		col = 0;
		row = 0; 
		
	}
	
	else
	{
		col = start / 0x10;
		row = start % 0x10;
	}
	
	columnEnd = end / 0x10;
	rowEnd = end % 0x10;

	for(i=col; i <= columnEnd; ++i)
	{
		printf("%05X | ", (int)i * 0x10);
		for(j=0; j != 0x10; ++j)
		{
			if((col == (int)i) && (j < row))
			{
				printf("  ");
			}
			else if(((columnEnd) == (int)i) && (j > rowEnd))
			{
				printf("  ");
			}
			else
			{
				printf("%02X", virtualMemory.Memory[i][j]);
			}
			printf(" ");
		}
		printf("; ");


		for(j = 0; j != 0x10; ++j)
		{
			if((col == ((int)i)) && (j < row))
			{
				
				printf(".");
			}
			else if((columnEnd == (int)i) && (j > rowEnd))
			{
				printf(".");
			}
			else if(virtualMemory.Memory[i][j] >= virtualMemory.minimumASCII && 
					virtualMemory.Memory[i][j] <= virtualMemory.maximumASCII)
			{
				printf("%c", (char)virtualMemory.Memory[i][j]);
			}
			else
			{
				printf(".");
			}
		}
		printf("\n");
	}
	last = end+1;
	return 0;
}

//Returns 0 when a string is empty
int IsStringEmpty(char *str)
{
	if(strcmp(str, "empty")==0)
		return 1;

	return 0;
}

//converts string to hexadecimal
int ConvertStringToHex(char *str)
{
	
	int stringLength = strlen(str);
	
	int result = 0;
	
	
	if(stringLength >= 2)
	{
		result = ConvertCharToASCII(str[stringLength-1]);
		result += ConvertCharToASCII(str[stringLength-2])*0x10;
	}
	else if(stringLength == 1)
	{
		result = ConvertCharToASCII(str[0]);
	}
	else
		result = -1;

	return result;
}

//converts char to ASCII codes
int ConvertCharToASCII(char a)
{
	int result = 0;
	
	
	if(a >= 'A' && a <= 'F')
		result = a - 55;
	else if(a >= 'a' && a <= 'f')
		result = a - 87;
	else if(a >= '0' && a <= '9')
		result = a - 48;
	
	
	return result;
}

//initialize the virtual memory 
void InitializeMemory()
{
	size_t i = 0;
	virtualMemory.sizeOfMemory = 16*65536;
	virtualMemory.columnOfMemory = 65536;
	virtualMemory.rowOfMemory = 16;
	virtualMemory.minimumASCII = 0x20;
	virtualMemory.maximumASCII = 0x7E;
	virtualMemory.maximumByte = 0xFF;

	virtualMemory.Memory = (unsigned int**)malloc(sizeof(unsigned int**) * virtualMemory.columnOfMemory);

	for(i = 0; i != virtualMemory.columnOfMemory; ++i)
	{
		virtualMemory.Memory[i] = (unsigned int*)calloc(sizeof(unsigned int*), virtualMemory.rowOfMemory);
	}
}


// Free memory allocation for virtual memory
void FreeMemory()
{
	size_t i=0;
	for(i=0; i != virtualMemory.columnOfMemory; ++i)
		free(virtualMemory.Memory[i]);
	free(virtualMemory.Memory);
}

//Modifies first argument of any command for passing into other function
void ProcessDumpArgument()
{
	int i=0;
	int stringLength = 0;
	//char tempString[20];


	stringLength= strlen(cmdArgument[1].argument);

	for(i=0;i<stringLength;i++)
	{
		if(cmdArgument[1].argument[i] == ',')
		{
			cmdArgument[1].argument[i] = '\0';
			break;
		}
	}
}

//Modifies second argument of any command for passing into other function
void ProcessDumpArgument2()
{
	int i=0;
	int stringLength = 0;
//	char tempString[20];


	stringLength= strlen(cmdArgument[2].argument);

	for(i=0;i<stringLength;i++)
	{
		if(cmdArgument[2].argument[i] == ',')
		{
			cmdArgument[2].argument[i] = '\0';
			break;
		}
	}
	
}

//Edits memory content of vitual memory from a particular address
int EditMemoryContent(char *address, char *value)
{
	int addressInHex = 0;
	int valueInHex = 0;
	int col=0, row=0;
	if(IsStringEmpty(address))
		return 1;
	if(IsStringEmpty(value))
		return 1;

	addressInHex = ConvertStringToHex(address);
	valueInHex = ConvertStringToHex(value);
	
	row = addressInHex % 0x10;
	col = addressInHex / 0x10;
	

	virtualMemory.Memory[col][row] = valueInHex;
	return 0;
}

//Fill virtual memory from start address to end address with a certain value
int FillMemory(char *start, char *end, char *value)
{
	int startInHexadecimal = 0;
	int endInHexadecimal = 0;
	int valueInHex = 0;
	size_t start_col = 0;
	size_t start_row = 0;
	size_t columnEnd = 0;
	size_t rowEnd = 0;
	size_t i = 0, j = 0;

	// Verify, 1 is false
	if(IsStringEmpty(value))
		return 1;
	
	if(IsStringEmpty(start))
		return 1;
	
	if(IsStringEmpty(end))
		return 1;
	

	startInHexadecimal = ConvertStringToHex(start);
	endInHexadecimal = ConvertStringToHex(end);
	valueInHex = ConvertStringToHex(value);
	
	if(valueInHex < 0 || valueInHex > virtualMemory.maximumByte)
		return 1;
	if(startInHexadecimal >= endInHexadecimal)
		return 1;
	
	if(startInHexadecimal < 0 || startInHexadecimal >= virtualMemory.sizeOfMemory)
		return 1;
	if(endInHexadecimal < 0 || endInHexadecimal >= virtualMemory.sizeOfMemory)
		return 1;
	

	start_row = startInHexadecimal % 0x10;
	start_col = startInHexadecimal / 0x10;
	
	rowEnd = endInHexadecimal % 0x10;
	columnEnd = endInHexadecimal / 0x10;
	

	for(i=start_col; i <= columnEnd; ++i)
	{
		for(j=start_row; j != 0x10; ++j)
		{
			if((i == columnEnd) && (j > rowEnd))
				break;
			virtualMemory.Memory[i][j] = valueInHex;
		}
	}
	return 0;
}

//Generate opcode list from opcode.txt
void InitializeOpcode()
{
	FILE* fp=fopen("opcode.txt","r");
	
	opcodelLinkedList* previous;
	opcodelLinkedList* after;
	
	
	opcodeAttribute temporary;
	int hashIndex;
	char opcodeNumber[5];
	
	
	int i;
	
	for(i=0;i<20;i++)
	{
		opcodeList[i]=NULL;
	}

	while(!feof(fp))
	{
			fscanf(fp,"%s", opcodeNumber);
			temporary.codeNum=ConvertCharToHex(opcodeNumber[0]);
			temporary.codeNum=temporary.codeNum*16+ConvertCharToHex(opcodeNumber[1]);
			fscanf(fp,"%s %s",temporary.code,temporary.format);	


	hashIndex=ProcessOpcodeToHash(temporary.code);
	
	
	if(!opcodeList[hashIndex])
	{
		opcodeList[hashIndex]=(opcodelLinkedList*)malloc(sizeof(opcodelLinkedList));
		opcodeList[hashIndex]->next=NULL;
		opcodeList[hashIndex]->attributes.codeNum=temporary.codeNum;
		strcpy(opcodeList[hashIndex]->attributes.code, temporary.code);
		strcpy(opcodeList[hashIndex]->attributes.format, temporary.format);

	}

	else
	{

		previous=after=opcodeList[hashIndex];
		while(after)
		{
			previous=after;
			after=after->next;
		}
	
		previous->next=(opcodelLinkedList*)malloc(sizeof(opcodelLinkedList));	
		previous=previous->next;
		previous->next=NULL;
		previous->attributes.codeNum=temporary.codeNum;
		strcpy(previous->attributes.code, temporary.code);
		strcpy(previous->attributes.format, temporary.format);
	}	
	}

	fclose(fp);
}


// return the hash number of an opcode
int ProcessOpcodeToHash(char* code)
{
	int sum;
	int i;
	
	int stringLength=strlen(code);
		for(i=0,sum=0; i< stringLength; i++)
		{
			sum+=3*code[i]+2*i;									
		}
			
		return (sum)%20;
}

// prints the whole opcode hash table
void PrintOpcodeList()
{
	int i;
	opcodelLinkedList *startIndex;

	//print opcode list	
	for(i=0;i<20;i++)
	{
		printf("%d : ",i);
		
		startIndex=opcodeList[i];
		
		if(startIndex)
		{
		printf("[%s,%X]",startIndex->attributes.code, startIndex->attributes.codeNum);
			startIndex=startIndex->next;
		}
		while(startIndex)
		{
			printf(" -> [%s,%X]",startIndex->attributes.code, startIndex->attributes.codeNum);
			startIndex=startIndex->next;
		}
		printf("\n");
	}

	return;
}

//searches opcode command and prints its opcode number
void SearchPrintSpecificOpcode(char* input)
{
	int i=0;
	int j=0;
	char code_[10];
	int hash_;
	opcodelLinkedList* startIndex;

	
	while(input[i]!='\0' && input[i]!=' ')
		i++;
	
	
	while(input[i]!='\0')
	{
		if(IsChaAlphabet(input[i]))
			code_[j++]=input[i];
		i++;
	}
	code_[j]='\0';
	
	hash_=ProcessOpcodeToHash(code_);

	startIndex=opcodeList[hash_];
	while(startIndex)
	{
		if(!strcmp(startIndex->attributes.code,code_)==0)
				startIndex=startIndex->next;
		else
		{
			printf("opcode is %X\n", startIndex->attributes.codeNum);
			break;
		}
	}

	return;
}
//returns whether the parameter is an alphabet
int IsChaAlphabet(char c)
{
	//uppercase alphabet
	if(c>='A' && c<='Z')
		return 1;
	//lowercase alphaber
	if(c>='a' && c<='z')
		return 1;
	
	else
		return 0;
}

//change the character parameter into hexa decimal
int ConvertCharToHex(char c)
{
	if(c>='0' && c<='9')
		return c-'0';
	
	switch(c)
	{
		case 'a' : return 10;
		case 'b' : return 11;
		case 'c' : return 12;
		case 'd' : return 13;
		case 'e' : return 14;
		case 'f' : return 15;
		
		case 'A' : return 10; 
		case 'B' : return 11;
		case 'C' : return 12;
		case 'D' : return 13;
		case 'E' : return 14;
		case 'F' : return 15;

	}
	return -1;
}


