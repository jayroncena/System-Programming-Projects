#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>

//=======================================
// COMMAND PROCESSING VARIABLES
//=======================================
const char *shellStartCommand = "sicsim> ";

// array of string commands in full form
char *commandNames[] = {"help","dir","quit","history","dump","edit","fill","reset","opcode","opcodelist"};
// array of string command in short form
char *altCommandNames[] = {"h","d","q","hi","du","e","f","reset","opcode","opcodelist"};

// array of string commands for help command
char *commandNamesHelp[] = {"h[elp]","d[ir]","q[uit]","hi[story]","du[mp] [start, end]","e[dit address, value]","f[ill] start, end, value","reset","opcode mnemonic","opcodelist"};

// structure to save the arguments of those command with arguments
typedef struct
{
	char* argument;
}cmdWithArgument;

// pointer to command arguments
cmdWithArgument *cmdArgument;

//=======================================
// HELP COMMAND FUNCTIONS
//=======================================
void Help();


//=======================================
// DIR COMMAND FUNCTION
//=======================================
void Dir();

//=======================================
// HISTORY COMMAND VARIABLE AND STRUTURE
//=======================================
//linked list for command history

typedef struct node
{
	char commandString[20];
	struct node* next;	
}node_t;

//pointer to history linked list
node_t* historyList = NULL;



//================================================================
//MEMORY MANAGEMENT-RELATED VARIABLES, STRUCTURES AND FUNCTIONS
//=================================================================


// structure to implement virtual memory.
struct virtualMemory_
{
	unsigned int **Memory;
	size_t sizeOfMemory;
	size_t columnOfMemory;
	size_t rowOfMemory;
	size_t minimumASCII;
	size_t maximumASCII;
	size_t maximumByte;
	
	
}virtualMemory;

//initialize virtual memory
void InitializeMemory();

// free virtual memory
void FreeMemory();

//modify first argument of any command for passing
void ProcessDumpArgument();

//modfiy second argument of any command for passing
void ProcessDumpArgument2();


//=========================================================
// DUMP COMMAND-RELATED VARIABLES, STRUCTURES AND FUNCTION
//=========================================================

// main dump function
int DumpMemory(char *start, char *end);

//dump without 2 arguments
int UntouchedDump();
//dump function with only start as an argument
int DumpWithStartOnly(int start);
//dump function with both start and end arguments
int DumpWithStartEnd(int start, int end);
// prints the current state of virtual memory
int PrintMemoryContent(int start, int end);// print
//checks if a string is empty
int IsStringEmpty(char *str);
///convert string to hexadecimal
int ConvertStringToHex(char *str);
//change character tp ASCII
int ConvertCharToASCII(char a);



//====================================================
// EDIT COMMAND-RELATED FUNCTION
//====================================================

int EditMemoryContent(char *address, char *value);

//====================================================
// FILL COMMAND-RELATED FUNCTION
//====================================================
int FillMemory(char *start, char *end, char *value);


//===========================================
// OPCODE COMMAND VARIABLES,STRUCTURE,FUNCTIONS
//===========================================
// structure to save opcode's information
typedef struct opcode_
{
	unsigned char codeNum;
	char code[10];
	char format[10];
}opcodeAttribute;
	
//linked list of opcode
typedef struct oplist
{
	opcodeAttribute attributes;
	struct oplist* next;
}opcodelLinkedList;

// pointer to opcode hash table	
opcodelLinkedList* opcodeList[20];

int ConvertCharToHex(char c);
void InitializeOpcode();
int ProcessOpcodeToHash(char* code);
int IsChaAlphabet(char C); //retrun 1 if parameter is in the range of alphabet
void PrintOpcodeList();
void SearchPrintSpecificOpcode(char* input);
