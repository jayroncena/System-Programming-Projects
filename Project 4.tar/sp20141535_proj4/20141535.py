#==========================================================================
#Subject	: 		System Programming
#Professor	:		Mr. UnSang Pak
#Title		:		Project #4 'Web Crawler'
#Student ID	:		20141535
#Name		:		Jayron
#Date		:		May 10,2017
#==========================================================================

from bs4 import BeautifulSoup
from lib_LocalFileAdapter import LocalFileAdapter # file:// transport adapter for requests
import requests
import os #for os io


requests_session = requests.session()
requests_session.mount('file://',LocalFileAdapter())

urlFileStream = open('URL.txt','w') #make and open a file stream for URL.txt

startHTMLPage ="index"
origin = "file://"+os.getcwd()+"/public_html/" #local address of the html pages	
					
numberOfLink=0 #count of the number of links
httpOKStatus = 200 #a constant that specifies http status
listOfPage = []		#path of URL visited									

def AddToURLlistAndContent(startHTMLPage,soup):
#it is a function to write visited pages in URL.txt and the content of pages
	pageContentFileStream = open('Output_'+'%04d'%(numberOfLink) + '.txt','w')
	urlFileStream.write('[%d]'%(numberOfLink) +'./public_html/'+ startHTMLPage + ".html\n")
	pageContentFileStream.write(soup.text)
	
def GetAllHyperlinksAndContent(startHTMLPage): 
#it is a recursive function to search all hyperlinks from page											
	global origin
	global urlFileStream
	global numberOfLink
	global pageNonExisting
	global statusCode

	r = requests_session.get(origin + startHTMLPage + ".html") #get local address
	
	pageNonExisting = listOfPage.count(startHTMLPage) #page does not exist
	statusCode = r.status_code # get the status of http
	
	if  pageNonExisting != 0:
		return 
	elif statusCode != httpOKStatus: # status code is not ok
		return			
	else:
		listOfPage.append(startHTMLPage)					
		numberOfLink = numberOfLink + 1 # increase the count of number of hyperlinks

	soup = BeautifulSoup(r.content,"html.parser") 
	links = soup.find_all('a')		#get all the hyperlinks from the page			

	AddToURLlistAndContent(startHTMLPage,soup) #call the function to write in the txt file

	for link in links:
		tag = link.get('href')

		if tag.find("html") == -1:
			continue			
		else:
			startHTMLPage = tag[:tag.find('.')]
			GetAllHyperlinksAndContent(startHTMLPage) #recursional search
			

GetAllHyperlinksAndContent(startHTMLPage) # call the recursive function to search for hyperlinks
