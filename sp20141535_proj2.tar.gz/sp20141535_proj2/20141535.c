#include "20141535.h"

#define SAME_STR(s1,s2) (strcmp(s1,s2)==0)

// get the command from user input
int GetCommand(char *command);

// push a node into history linked list
void Push(char* commandString);

//count the number wrong command
int noErrorCommand = 0;

//saves the last dump
int last = 0;

//counts number of arguments supplied for dump command
int dumpFlag = 0;

//counts number of argumnets
int count=0;

//Project 2
int indexCommand=0;
commandStruct commandLine[MAX_COM_LINE];
int currentLocation;
int inputErr; //check error
int baseRegister=99999999; //temporary
int registerPC;

int main(void)
{
	int i=0;
	int k;
	
	char command[20];// input of the user
	int commandInt;//corresponding command number for different cases
	int flag=0;// saves status of dump command
	
	//int check=0;

	InitializeMemory(); //initialize the virtual memory
	InitializeOpcode(); // makes the opcode hash table
	

	while(1)
	{
		noErrorCommand = 0;	
		
		// allocate memory for command arguments
		cmdArgument = (cmdWithArgument*)malloc(sizeof(cmdWithArgument)*4);
		
		for (i = 0; i < 4; ++i) 
		{
			cmdArgument[i].argument = malloc(sizeof(char)*40);
		}
		
		printf("%s", shellStartCommand);
		
		fgets(command,sizeof(command),stdin); //get user input
		commandInt= GetCommand(command); // get corresponfing command number

		if(commandInt < 13)
		{
			switch(commandInt)
			{

			case 0:{
					Help();
					break;
				}
			case 1:{
					Dir();
					break;
				}
			case 2:{
					printf("EXITING PROGRAM\n");
					FreeMemory();
					return 0;
				}
			case 3:{
						Push(command);
						noErrorCommand = 1;
						i=1;
						node_t *temp;
						temp = historyList;
						while(temp != NULL)
						{
							printf("%d %s", i, temp->commandString);
							i++;
							temp=temp->next;
						}
						break;
					}
			case 4:{
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							flag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							flag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else
						{
							ProcessDumpArgument();
							flag=DumpMemory(cmdArgument[1].argument,cmdArgument[2].argument);
							dumpFlag=0;
							if(flag)
								return 0;
						}												
						break;
					}
			case 5:{
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							flag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							printf("[ERROR] MUST ENTER ADDRESS AND VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							flag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							printf("[ERROR] MUST ENTER VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else
						{
							ProcessDumpArgument();
							flag=EditMemoryContent(cmdArgument[1].argument,cmdArgument[2].argument);
							if(flag)
								return 0;
						}		
						break;
					}
			case 6:{
						if(dumpFlag == 1)
						{
							strcpy(cmdArgument[1].argument,"empty");
							strcpy(cmdArgument[2].argument,"empty");
							strcpy(cmdArgument[3].argument,"empty");
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("[ERROR] MUST ENTER START, END AND VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==2)
						{
							strcpy(cmdArgument[2].argument,"empty");
							strcpy(cmdArgument[3].argument,"empty");
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("[ERROR] MUST ENTER END AND VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else if(dumpFlag ==3)
						{
							ProcessDumpArgument();
							strcpy(cmdArgument[3].argument,"empty");
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							printf("[ERROR] MUST ENTER VALUE\n");
							dumpFlag=0;
							if(flag)
								return 0;
						}
						else
						{
							ProcessDumpArgument();
							ProcessDumpArgument2();
							flag=FillMemory(cmdArgument[1].argument,cmdArgument[2].argument,cmdArgument[3].argument);
							if(flag)
								return 0;
						}		
						break;
						
					}
			case 7:{
				       for(i=0; i != virtualMemory.columnOfMemory; ++i)
					       for(k=0; k!= virtualMemory.rowOfMemory;++k)
						       virtualMemory.Memory[i][k] = 0;
				       break;
				}
			case 8:{
						SearchPrintSpecificOpcode(command);
						break;
					}	
			case 9:{
						PrintOpcodeList();
						break;
					}
			case 10:{
						if(count == 1)
						{
							printf("[ERROR] SPECIFY FILENAME TO ASSEMBLE\n");
							break;
						}
						AssembleFile(cmdArgument[1].argument);
						break;
					}
			case 11:{
						if(count == 1)
						{
							printf("[ERROR] SPECIFY FILENAME YOU WANT TO VIEW\n");
							break;
						}
						DisplayFileContent(cmdArgument[1].argument);
						break;
					}
			case 12:{
						ShowSymbolTable();
						break;
					}
			}
		}
		else
		{
			printf("[ERROR] INVALID COMMAND or TOO MANY ARGUMENTS \n");
			noErrorCommand = 1;
		}		
		if(noErrorCommand == 0)
		{
			Push(command);
		}
	
	//free memory allocation
		for (i = 0; i < 4; ++i) 
		{
			free(cmdArgument[i].argument);
		}
		free(cmdArgument);
		dumpFlag=0;
	}
	FreeMemory();
	return 0;
}

// get the command that user wants by tokenizing the whole string into different arguments
int GetCommand(char *command)
{
	char *temp=NULL;
	char *temp2=NULL;
	char *savePtr=NULL;
	int i;

	count = 0;
	temp2 = (char*)malloc(sizeof(char)*20);
	strcpy(temp2,command);
	temp = strtok_r(temp2," \t\n",&savePtr);
	strcpy(cmdArgument[count].argument,temp);
	count++;
	
	while(temp != NULL)
	{
		dumpFlag++;
		if(count == 5)
		{
			return 13;
		}
		temp = strtok_r(NULL," \t\n",&savePtr);

		if (temp) {
			strcpy(cmdArgument[count].argument,temp);
			count++;
		}
	}


	for(i=0;i<=13;i++)
	{
		if(i==13)
		{
			return 13;
		}
		if((strcmp(cmdArgument[0].argument,commandNames[i]))== 0 || (strcmp(cmdArgument[0].argument, altCommandNames[i])) == 0 )
		{
			return i;
		}
	}
	free(temp2);
	return 0;
}

//Prints all the kind of commands the user can input
void Help()
{
	int i;
	
	for(i=0; i<13;i++)
	{
		printf("%s\n",commandNamesHelp[i]);

	}
}

//Prints directories under current diretory and files below it
void Dir()
{
	int i=0;
	DIR *directoryStream = NULL;
	struct dirent *directory = NULL;
					
	directoryStream=opendir(".");
	directory = readdir(directoryStream);
					
	for(;directory!=NULL;directory= readdir(directoryStream))
	{
		i++;
		struct stat directoryFile;
		if(stat((const char*)directory->d_name,&directoryFile)!=0)
			printf("[ERROR] FILE WAS NOT FOUND\n");
		if((strcmp(directory->d_name,"."))==0 || (strcmp(directory->d_name,".."))==0)
		{
			i--;
			continue;
		}
		printf("%s", directory->d_name);
		if(S_ISDIR(directoryFile.st_mode))
			printf("/");
		if((directoryFile.st_mode & S_IXOTH) || (directoryFile.st_mode & S_IXGRP) || (directoryFile.st_mode & S_IXUSR))
			printf("*");
		printf("\t");
		if(i==3)
		{
			printf("\n");
			i=0;
		}

	}
	printf("\n");
	closedir(directoryStream);
}

//store the whole input from user to the linked list
void Push(char* commandString)
{
	node_t* tempA;
	node_t* tempB;

	
	if(!historyList)
	{
		historyList = (node_t*)malloc(sizeof(node_t));
		strcpy((char*)(historyList->commandString),(char*)commandString);
		historyList->next=NULL;
	}
	
	else
	{
		tempA=tempB=historyList;
		tempB=tempB->next;

		while(tempB)
		{
			tempA=tempB;
			tempB=tempB->next;
		}

		tempA->next = (node_t*)malloc(sizeof(node_t));
		
		tempA=tempA->next;

		strcpy((char*)tempA->commandString,(char*) commandString);
		tempA->next=NULL;
	}

	return;
}

// dump virtual memory from the start to end
int DumpMemory(char *start, char *end)
{
	int startInHexadecimal=0;
	int endInHexadecimal=0;
	
	
	IsStringEmpty(start)==1?
		startInHexadecimal = -1 : (startInHexadecimal = ConvertStringToHex(start));

	IsStringEmpty(end)==1?
		endInHexadecimal = -1 : (endInHexadecimal = ConvertStringToHex(end));
	
	if(startInHexadecimal == -1 && endInHexadecimal == -1)
		UntouchedDump();
	else if(startInHexadecimal >= 0 && endInHexadecimal == -1)
		DumpWithStartOnly(startInHexadecimal);
	else
		DumpWithStartEnd(startInHexadecimal, endInHexadecimal);
	
	return 0;
}

//executes when there are no provide arguments for dump command
int UntouchedDump()
{
	int start = last;
	int end = last + (0x10 * 10)-1;
	int result = 0;
	
	
	PrintMemoryContent(start, end);

	return result;
}

//executes when there is only start as an argument for dump command
int DumpWithStartOnly(int start)
{
	int end = start + (0x10 * 10)-1;
	int result = 0;

	if((start % 0x10) > 0)
		end -= 0x10;

	PrintMemoryContent(start, end);


	return result;
}

//executes when there both start and end argument are supplied
int DumpWithStartEnd(int start, int end)
{
	int result = 0;
	
	PrintMemoryContent(start, end);


	return result;
}

//prints the current content of the virtual memory
int PrintMemoryContent(int start, int end)
{
	size_t rowEnd = 0;
	size_t columnEnd = 0;
	
	size_t row = 0;
	size_t col = 0;

	size_t i = 0;
	size_t j = 0;


	if(start >= virtualMemory.sizeOfMemory)
		return 1;
	if(end >= virtualMemory.sizeOfMemory)
		return 1;
	if(start >= end)
		return 1;
	
	if(start < 0)
		return 1;
	if(end < 0)
		return 1;


	printf("START: %02X\n", start);
	printf("END: %02X\n", end);

	if(start == 0)
	{
		col = 0;
		row = 0; 
		
	}
	
	else
	{
		col = start / 0x10;
		row = start % 0x10;
	}
	
	columnEnd = end / 0x10;
	rowEnd = end % 0x10;

	for(i=col; i <= columnEnd; ++i)
	{
		printf("%05X | ", (int)i * 0x10);
		for(j=0; j != 0x10; ++j)
		{
			if((col == (int)i) && (j < row))
			{
				printf("  ");
			}
			else if(((columnEnd) == (int)i) && (j > rowEnd))
			{
				printf("  ");
			}
			else
			{
				printf("%02X", virtualMemory.Memory[i][j]);
			}
			printf(" ");
		}
		printf("; ");


		for(j = 0; j != 0x10; ++j)
		{
			if((col == ((int)i)) && (j < row))
			{
				
				printf(".");
			}
			else if((columnEnd == (int)i) && (j > rowEnd))
			{
				printf(".");
			}
			else if(virtualMemory.Memory[i][j] >= virtualMemory.minimumASCII && 
					virtualMemory.Memory[i][j] <= virtualMemory.maximumASCII)
			{
				printf("%c", (char)virtualMemory.Memory[i][j]);
			}
			else
			{
				printf(".");
			}
		}
		printf("\n");
	}
	last = end+1;
	return 0;
}

//Returns 0 when a string is empty
int IsStringEmpty(char *str)
{
	if(strcmp(str, "empty")==0)
		return 1;

	return 0;
}

//converts string to hexadecimal
int ConvertStringToHex(char *str)
{
	
	int stringLength = strlen(str);
	
	int result = 0;
	
	
	if(stringLength >= 2)
	{
		result = ConvertCharToASCII(str[stringLength-1]);
		result += ConvertCharToASCII(str[stringLength-2])*0x10;
	}
	else if(stringLength == 1)
	{
		result = ConvertCharToASCII(str[0]);
	}
	else
		result = -1;

	return result;
}

//converts char to ASCII codes
int ConvertCharToASCII(char a)
{
	int result = 0;
	
	
	if(a >= 'A' && a <= 'F')
		result = a - 55;
	else if(a >= 'a' && a <= 'f')
		result = a - 87;
	else if(a >= '0' && a <= '9')
		result = a - 48;
	
	
	return result;
}

//initialize the virtual memory 
void InitializeMemory()
{
	size_t i = 0;
	virtualMemory.sizeOfMemory = 16*65536;
	virtualMemory.columnOfMemory = 65536;
	virtualMemory.rowOfMemory = 16;
	virtualMemory.minimumASCII = 0x20;
	virtualMemory.maximumASCII = 0x7E;
	virtualMemory.maximumByte = 0xFF;

	virtualMemory.Memory = (unsigned int**)malloc(sizeof(unsigned int**) * virtualMemory.columnOfMemory);

	for(i = 0; i != virtualMemory.columnOfMemory; ++i)
	{
		virtualMemory.Memory[i] = (unsigned int*)calloc(sizeof(unsigned int*), virtualMemory.rowOfMemory);
	}
}


// Free memory allocation for virtual memory
void FreeMemory()
{
	size_t i=0;
	for(i=0; i != virtualMemory.columnOfMemory; ++i)
		free(virtualMemory.Memory[i]);
	free(virtualMemory.Memory);
}

//Modifies first argument of any command for passing into other function
void ProcessDumpArgument()
{
	int i=0;
	int stringLength = 0;
	//char tempString[20];


	stringLength= strlen(cmdArgument[1].argument);

	for(i=0;i<stringLength;i++)
	{
		if(cmdArgument[1].argument[i] == ',')
		{
			cmdArgument[1].argument[i] = '\0';
			break;
		}
	}
}

//Modifies second argument of any command for passing into other function
void ProcessDumpArgument2()
{
	int i=0;
	int stringLength = 0;
//	char tempString[20];


	stringLength= strlen(cmdArgument[2].argument);

	for(i=0;i<stringLength;i++)
	{
		if(cmdArgument[2].argument[i] == ',')
		{
			cmdArgument[2].argument[i] = '\0';
			break;
		}
	}
	
}

//Edits memory content of vitual memory from a particular address
int EditMemoryContent(char *address, char *value)
{
	int addressInHex = 0;
	int valueInHex = 0;
	int col=0, row=0;
	if(IsStringEmpty(address))
		return 1;
	if(IsStringEmpty(value))
		return 1;

	addressInHex = ConvertStringToHex(address);
	valueInHex = ConvertStringToHex(value);
	
	row = addressInHex % 0x10;
	col = addressInHex / 0x10;
	

	virtualMemory.Memory[col][row] = valueInHex;
	return 0;
}

//Fill virtual memory from start address to end address with a certain value
int FillMemory(char *start, char *end, char *value)
{
	int startInHexadecimal = 0;
	int endInHexadecimal = 0;
	int valueInHex = 0;
	size_t start_col = 0;
	size_t start_row = 0;
	size_t columnEnd = 0;
	size_t rowEnd = 0;
	size_t i = 0, j = 0;

	// Verify, 1 is false
	if(IsStringEmpty(value))
		return 1;
	
	if(IsStringEmpty(start))
		return 1;
	
	if(IsStringEmpty(end))
		return 1;
	

	startInHexadecimal = ConvertStringToHex(start);
	endInHexadecimal = ConvertStringToHex(end);
	valueInHex = ConvertStringToHex(value);
	
	if(valueInHex < 0 || valueInHex > virtualMemory.maximumByte)
		return 1;
	if(startInHexadecimal >= endInHexadecimal)
		return 1;
	
	if(startInHexadecimal < 0 || startInHexadecimal >= virtualMemory.sizeOfMemory)
		return 1;
	if(endInHexadecimal < 0 || endInHexadecimal >= virtualMemory.sizeOfMemory)
		return 1;
	

	start_row = startInHexadecimal % 0x10;
	start_col = startInHexadecimal / 0x10;
	
	rowEnd = endInHexadecimal % 0x10;
	columnEnd = endInHexadecimal / 0x10;
	

	for(i=start_col; i <= columnEnd; ++i)
	{
		for(j=start_row; j != 0x10; ++j)
		{
			if((i == columnEnd) && (j > rowEnd))
				break;
			virtualMemory.Memory[i][j] = valueInHex;
		}
	}
	return 0;
}

//Generate opcode list from opcode.txt
void InitializeOpcode()
{
	FILE* fp=fopen("opcode.txt","r");
	
	opcodelLinkedList* previous;
	opcodelLinkedList* after;
	
	
	opcodeAttribute temporary;
	int hashIndex;
	char opcodeNumber[5];
	
	
	int i;
	
	for(i=0;i<20;i++)
	{
		opcodeList[i]=NULL;
	}

	while(!feof(fp))
	{
			fscanf(fp,"%s", opcodeNumber);
			temporary.codeNum=ConvertCharToHex(opcodeNumber[0]);
			temporary.codeNum=temporary.codeNum*16+ConvertCharToHex(opcodeNumber[1]);
			fscanf(fp,"%s %s",temporary.code,temporary.format);	


	hashIndex=ProcessOpcodeToHash(temporary.code);
	
	
	if(!opcodeList[hashIndex])
	{
		opcodeList[hashIndex]=(opcodelLinkedList*)malloc(sizeof(opcodelLinkedList));
		opcodeList[hashIndex]->next=NULL;
		opcodeList[hashIndex]->attributes.codeNum=temporary.codeNum;
		strcpy(opcodeList[hashIndex]->attributes.code, temporary.code);
		strcpy(opcodeList[hashIndex]->attributes.format, temporary.format);

	}

	else
	{

		previous=after=opcodeList[hashIndex];
		while(after)
		{
			previous=after;
			after=after->next;
		}
	
		previous->next=(opcodelLinkedList*)malloc(sizeof(opcodelLinkedList));	
		previous=previous->next;
		previous->next=NULL;
		previous->attributes.codeNum=temporary.codeNum;
		strcpy(previous->attributes.code, temporary.code);
		strcpy(previous->attributes.format, temporary.format);
	}	
	}

	fclose(fp);
}


// return the hash number of an opcode
int ProcessOpcodeToHash(char* code)
{
	int sum;
	int i;
	
	int stringLength=strlen(code);
		for(i=0,sum=0; i< stringLength; i++)
		{
			sum+=3*code[i]+2*i;									
		}
			
		return (sum)%20;
}

// prints the whole opcode hash table
void PrintOpcodeList()
{
	int i;
	opcodelLinkedList *startIndex;

	//print opcode list	
	for(i=0;i<20;i++)
	{
		printf("%d : ",i);
		
		startIndex=opcodeList[i];
		
		if(startIndex)
		{
		printf("[%s,%X]",startIndex->attributes.code, startIndex->attributes.codeNum);
			startIndex=startIndex->next;
		}
		while(startIndex)
		{
			printf(" -> [%s,%X]",startIndex->attributes.code, startIndex->attributes.codeNum);
			startIndex=startIndex->next;
		}
		printf("\n");
	}

	return;
}

//searches opcode command and prints its opcode number
void SearchPrintSpecificOpcode(char* input)
{
	int i=0;
	int j=0;
	char code_[10];
	int hashNumber;
	opcodelLinkedList* startIndex;

	
	while(input[i]!='\0' && input[i]!=' ')
		i++;
	
	
	while(input[i]!='\0')
	{
		if(IsChaAlphabet(input[i]))
			code_[j++]=input[i];
		i++;
	}
	code_[j]='\0';
	
	hashNumber=ProcessOpcodeToHash(code_);

	startIndex=opcodeList[hashNumber];
	while(startIndex)
	{
		if(!strcmp(startIndex->attributes.code,code_)==0)
				startIndex=startIndex->next;
		else
		{
			printf("OPCODE IS  %X\n", startIndex->attributes.codeNum);
			break;
		}
	}

	return;
}
//returns whether the parameter is an alphabet
int IsChaAlphabet(char c)
{
	//uppercase alphabet
	if(c>='A' && c<='Z')
		return 1;
	//lowercase alphaber
	if(c>='a' && c<='z')
		return 1;
	
	else
		return 0;
}

//change the character parameter into hexa decimal
int ConvertCharToHex(char c)
{
	if(c>='0' && c<='9')
		return c-'0';
	
	switch(c)
	{
		case 'a' : return 10;
		case 'b' : return 11;
		case 'c' : return 12;
		case 'd' : return 13;
		case 'e' : return 14;
		case 'f' : return 15;
		
		case 'A' : return 10; 
		case 'B' : return 11;
		case 'C' : return 12;
		case 'D' : return 13;
		case 'E' : return 14;
		case 'F' : return 15;

	}
	return -1;
}

void AssembleFile(char* fileName)
{
	//File streams
	FILE* fp;
	FILE* fpListFileStream;
	FILE* fpObjectFileStream;
	char listFileName[50];
	char objectFileName[50];
	
	int j,k;
	int idxToken;
	int commaFlag=0;
	
	char buffer[255];
	char temporary[3][MAX_COM_LEN];
	char *cutChar;
	char temporary2[MAX_COM_LEN];
	char* fixedOperand;
	

	//initiation
	baseRegister = 99999999;
	symTab=NULL;
	indexCommand=0;

	if((fp=fopen(fileName,"r"))==NULL)
	{
		printf("[ERROR] WRONG FILENAME. THE FILE DOES NOT EXIST\n");
		inputErr=1;
		return;
	}
	 //create and open a list file
	strcpy(temporary2,fileName);
	cutChar=strtok(temporary2,".");
	strcpy(listFileName,cutChar);
	strcat(listFileName,".lst");
	fpListFileStream=fopen(listFileName,"w");

	//create and open an object file
	strcpy(temporary2,fileName);
	cutChar=strtok(temporary2,".");
	strcpy(objectFileName,cutChar);
	strcat(objectFileName,".obj");
	fpObjectFileStream=fopen(objectFileName,"w");

//saves each line of command to commandLine
	while(!feof(fp))
	{
		fgets(buffer,254,fp);
		
		commaFlag=0;
		idxToken=0;
	
		if(strchr(buffer,','))
		{
			commaFlag=1;
		}
		//first command argument
		cutChar=strtok(buffer," 	\n");
		
		//if there is no command or if command involves '.'
		if(cutChar==NULL || SAME_STR(cutChar,"."))
			continue;
		
		
		//saves the command into temporary
		strcpy(temporary[idxToken++],cutChar);
		//second command argument
		cutChar=strtok(NULL," 	\n");


		if(cutChar!=NULL)
		{
			strcpy(temporary[idxToken],cutChar);
			idxToken++;
			
			//third command argument
			cutChar = strtok(NULL,"\n");
			if(cutChar!=NULL)
			{	
				j=0;
				while(cutChar[j]!='\0')
				{
					if(cutChar[j]!=' ')
						break;
					j++;
				}
				
				if(cutChar[j]!='\0')
				{
					if(commaFlag==1)
					{	
						strcat(temporary[--idxToken],cutChar);
					}
					else
						strcpy(temporary[idxToken],cutChar);
					
					idxToken++;
					
				}
			}	
		}

		if(idxToken==1)
		{
			commandLine[indexCommand].symbol[0]='\0';
			commandLine[indexCommand].operand[0]='\0';
			
			strcpy(commandLine[indexCommand].op_code,temporary[0]);

		}
		else if(idxToken==2)
		{
			commandLine[indexCommand].symbol[0]='\0';
			strcpy(commandLine[indexCommand].op_code,temporary[0]);
			
			EliminateWhiteSpace(temporary[1],&fixedOperand);
			
			strcpy(temporary[1],fixedOperand);
			strcpy(commandLine[indexCommand].operand,temporary[1]);
		}
		else if(idxToken==3)
		{		
			strcpy(commandLine[indexCommand].symbol,temporary[0]);
			strcpy(commandLine[indexCommand].op_code,temporary[1]);

			k=0;
			
			if(SAME_STR(commandLine[indexCommand].op_code,"BYTE"))
			{
				j=0;
				
				while(temporary[2][j]!='\0' && temporary[2][j]==' ')
				{	
					j++;
				}
				strcpy(temporary[2],&(temporary[2][j]));
				//do not remove blank
				if(temporary[2][0]=='X' || temporary[2][0]=='C')
					k=1;
			}
			
			if(k==0)
			{
				EliminateWhiteSpace(temporary[2],&fixedOperand);
				strcpy(temporary[2],fixedOperand);
			}
			
			strcpy(commandLine[indexCommand].operand,temporary[2]);
		}

		//Pass 1 Algorithm
		AssemblePassOne(); 
		indexCommand++;
	}

		if(inputErr==1)
		{
			symTab=NULL;
			baseRegister=99999999;
			indexCommand=0;
			return;
		}
	

	//Pass 2 algorithm
	AssemblePassTwoList(fpListFileStream,fpObjectFileStream);
	if(inputErr==1)
	{
		symTab=NULL;
		baseRegister=99999999;
		indexCommand=0;
		return;
	}
	
	//close file streams
	fclose(fp);
	fclose(fpListFileStream);
	fclose(fpObjectFileStream);
}

//Executes Pass 1 algorithm
void AssemblePassOne()
{
	int locationCounter=0;
	int hashNumber;
	char *cutChar;
	char temporary[MAX_COM_LEN];
	
	opcodelLinkedList* searchOpcode;
	
	if(SAME_STR(commandLine[indexCommand].op_code,"START"))
	{
		
		if((currentLocation=StringToDecimal(commandLine[indexCommand].operand))==-1)
		{
			printf("[ERROR] %06X : WRONG ADDRESS\n",commandLine[indexCommand].location);
			return;
		}
			
		commandLine[indexCommand].location=currentLocation;
		
		//add to symbol table
		AddToSymbolTable(commandLine[indexCommand]);
				
		if(inputErr==1)
			return;
	}


	else
	{
		if(commandLine[indexCommand].operand[0]!='\0' && commandLine[indexCommand].symbol[0]=='\0')
		{
			hashNumber=ProcessOpcodeToHash(commandLine[indexCommand].operand);
			
			searchOpcode=opcodeList[hashNumber];
			
			while(searchOpcode)
			{
				if(SAME_STR(searchOpcode->attributes.code,commandLine[indexCommand].operand))
				{
					strcpy(commandLine[indexCommand].op_code,commandLine[indexCommand].operand);
					strcpy(commandLine[indexCommand].symbol,commandLine[indexCommand].op_code);
					
					commandLine[indexCommand].operand[0]='\0';
				}
				else
					searchOpcode=searchOpcode->next;

			}

		}


		//put currentLocation to commandline
		commandLine[indexCommand].location=currentLocation;
		
		//reinitialize location counter
		locationCounter=0; 
		
		
		if(commandLine[indexCommand].symbol[0]!='\0')
		{
			if(!IsThereSymbolTag(commandLine[indexCommand]))
			{
				printf("[ERROR] %06X : WRONG LABEL\n",commandLine[indexCommand].location);
			}
			//save symbol to symbol table
			else
			{
				AddToSymbolTable(commandLine[indexCommand]);
				
				if(inputErr==1)
					return;
			}
		}

		if(SAME_STR(commandLine[indexCommand].op_code,"RESB"))//variable RESB
		{
			
			if((locationCounter=StringToDecimal(commandLine[indexCommand].operand))==-1)
			{
				printf("[ERROR] %06X : [NOT ENOUGH LINE]\n",commandLine[indexCommand].location);
				inputErr=1;
				return;
			}
		}
			
		
		else if(SAME_STR(commandLine[indexCommand].op_code,"RESW"))//variable RESW
		{
			
			if((locationCounter=StringToDecimal(commandLine[indexCommand].operand))==-1)
			{
				printf("[ERROR] %06X : [NOT ENOUGH LINE]\n",commandLine[indexCommand].location);
				inputErr=1;
				return;
			}
			locationCounter*=3;
		}
		
		else if(SAME_STR(commandLine[indexCommand].op_code,"BYTE"))// constant BYTE
		{
			locationCounter=1; //because the size is BYTE
			
			//if the number is 16 antilogarithm
			if(commandLine[indexCommand].operand[0]=='X')
			{
				locationCounter=1;
			}
			if(commandLine[indexCommand].operand[0]=='C')
			{
				strcpy(temporary,&commandLine[indexCommand].operand[1]);
				cutChar=strtok(temporary,"'");
				locationCounter=strlen(cutChar);
			}
		}
			
		else if(SAME_STR(commandLine[indexCommand].op_code,"WORD"))// constant WORD
		{
			locationCounter=3;
		}

		else if(commandLine[indexCommand].op_code[0]=='+')// for operands with + symbol
		{
			locationCounter=4;
	
			if(IsOpcode(&commandLine[indexCommand].op_code[1])==0)
			{
				inputErr=1;
				printf("[ERROR] %06X : [WRONG OPCODE]\n",commandLine[indexCommand].location);
				return;
			}
		}
		
		//Test which among 3 formats
		else if(locationCounter==0)
		{
			hashNumber=ProcessOpcodeToHash(commandLine[indexCommand].op_code);
			searchOpcode=opcodeList[hashNumber];
			
			while(searchOpcode)
			{
				 if(strcmp(searchOpcode->attributes.code,commandLine[indexCommand].op_code)!=0)
    		        searchOpcode=searchOpcode->next;
		         else
				 {
					 
					if(strncmp(searchOpcode->attributes.format,"1",1)==0)//format 1
						locationCounter=1;
						
					else if(strncmp(searchOpcode->attributes.format,"2",1)==0)//format 2
						locationCounter=2;
						
					else if(strncmp(searchOpcode->attributes.format,"3/4",3)==0)// format 3 or 4
						locationCounter=3;
				     break;
				 }
			}
			
			if(locationCounter==0 &&strcmp( commandLine[indexCommand].op_code,"BASE")!=0 && strcmp(commandLine[indexCommand].op_code,"END")!=0)
			{
				inputErr=1;
				printf("[ERROR] %06X : [WRONG OPCODE]\n",commandLine[indexCommand].location);
				return;
			}
		}

	}
	
	currentLocation+=locationCounter;
	
	return;

}


void AssemblePassTwoObject(FILE* fp) //make object code
{
	int hashNumber;
	int errorFlag;
	int flag;
	int constantFlag;
	int format4Flag;
	int addressOfOperand;
	int temporary;
	int objectCode;
	int i,j;
	
	char temp[MAX_COM_LEN];
	char temp2[MAX_COM_LEN];
	char* cutChar;
	
	opcodelLinkedList* searchOpcode;
	
// start to make object code for object file
	for(i=0;i<indexCommand;i++)
	{
		objectCode=0;
		commandLine[i].format=-1;
		registerPC=commandLine[i+1].location;
		
		if(SAME_STR(commandLine[i].op_code,"BASE"))//fixed base
		{
			baseRegister=SearchSymbolNumber(commandLine[i].operand);
			
			objectCode=-1;
		}


		//if the command is constants, 'byte'
		if(strcmp(commandLine[i].op_code,"BYTE")==0)
		{
			if(commandLine[i].operand[0]=='X')
			{
				strcpy(temp,&commandLine[i].operand[2]);
				cutChar=strtok(temp,"'");
				
				errorFlag=0;
				
				j=0;

				while(commandLine[i].operand[j]!='\0')
				{
					
					if(commandLine[i].operand[j]=='\'')
						errorFlag++;
					j++;
				}

				if(errorFlag!=2)
				{
					printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
					inputErr=1;
				}

				
				if(errorFlag==2 && strlen(cutChar)>30)//too long operand
				{
					printf("[ERROR]  %06X : [WRONG OPERAND]\n",commandLine[i].location);
					inputErr=1;
				}
				
				
				
				if(errorFlag==2 && strlen(cutChar)%2!=0)//not even number
				{
					printf("[ERROR]  %06X : [WRONG OPERAND]\n",commandLine[i].location);
					inputErr=1;
				}

				
				j=0;
				
				while(cutChar[j]!='\0')//wrong hexadecimal
				{
					if(!IsHexadecimal(cutChar[j]))
					{
						if(strlen(cutChar)%2==0 && errorFlag==2)
						printf("[ERROR]  %06X : [WRONG OPERAND]\n",commandLine[i].location);			
						inputErr=1;

					}
					j++;
				}

				objectCode=StringToHexadecimal(cutChar);
			}
			
			else if(commandLine[i].operand[0]=='C')
			{
				strcpy(temp,&commandLine[i].operand[2]);
				cutChar=strtok(temp,"'");
				
				j=0;
				errorFlag=0;
				
				
				while(commandLine[i].operand[j]!='\0')
				{
					if(commandLine[i].operand[j]=='\'')
							errorFlag++;
					j++;
				}
				
				if(errorFlag!=2)
				{
					printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
					inputErr=1;
				}
				
				j=0;
				
				if(errorFlag==2 && strlen(cutChar)>30)//too long
				{
					printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
					inputErr=1;
				}

				while(cutChar[j]!='\0')
				{
					if(j==0)
					{	
						commandLine[i].obj[j]=cutChar[j];
						objectCode+=cutChar[j];
					}
						
					else
					{
						commandLine[i].obj[j]=cutChar[j];
						objectCode=objectCode*16*16+cutChar[j];
					}
					
					
					j++;
				}
				
				
				commandLine[i].obj[j]='\0';
			}

			else
			{
				printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
				inputErr=1;

			}

		}

		else if( SAME_STR(commandLine[i].op_code,"RESB") || SAME_STR(commandLine[i].op_code,"RESW"))
		{
			
			if(!IsDecimal(commandLine[i].operand))
			{
				printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
				inputErr=1;

			}
			
			objectCode=-1;
		}
		
		//command is WORD
		else if(SAME_STR(commandLine[i].op_code,"WORD"))
		{
			
			
			if(!IsDecimal(commandLine[i].operand))
			{
				printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
				inputErr=1;

			}
			
			objectCode=StringToDecimal(commandLine[i].operand);
	
			
			if(objectCode >= 16*16*16*16*16*16)//out of range
			{
				printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
				inputErr=1;
				
				
			}
		
		}

		

		else
		{
			format4Flag=0;
			
			
			if(commandLine[i].op_code[0]=='+')//command is format 4
			{
				commandLine[i].format=4;
				format4Flag=1;
				strcpy(commandLine[i].op_code,&commandLine[i].op_code[1]);
			}
			
			
	
			hashNumber=ProcessOpcodeToHash(commandLine[i].op_code);
			searchOpcode=opcodeList[hashNumber];

			while(searchOpcode)
			{
				constantFlag=0;
				if(strcmp(searchOpcode->attributes.code, commandLine[i].op_code)!=0)
					searchOpcode=searchOpcode->next;
				else
				{	
					
					if(strncmp(searchOpcode->attributes.format,"1",1)==0)
					{		
						commandLine[i].format=1;
						
						if(commandLine[i].operand[0]!='\0')
						{
							printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
							inputErr=1;


						}
						objectCode=(int)searchOpcode->attributes.codeNum;

					}


					//format 2
					else if(strncmp(searchOpcode->attributes.format,"2",2)==0)
					{
						commandLine[i].format=2;
						
						
						if(strlen(commandLine[i].operand)==1)
						{
							
							if(FindRegisterNumber(commandLine[i].operand[0])==-1)
							{
								//wrong operand : not register
								printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
								inputErr=1;

							}
							objectCode=(int)(searchOpcode->attributes.codeNum)*16*16;
							objectCode+= FindRegisterNumber(commandLine[i].operand[0])*16;
						}

						else if(strlen(commandLine[i].operand)==3 && commandLine[i].operand[1]==',')
						{
							if(FindRegisterNumber(commandLine[i].operand[0])==-1 || FindRegisterNumber(commandLine[i].operand[2])==-1)
							{
								printf("[ERROR] %06X : [WRONG OPERAND]",commandLine[i].location);
								inputErr=1;
							}

							objectCode=(int)(searchOpcode->attributes.codeNum)*16*16;
							objectCode+= FindRegisterNumber(commandLine[i].operand[0])*16;
							objectCode+= FindRegisterNumber(commandLine[i].operand[2]);


						}
						else
						{
							printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
							inputErr=1;
						}

					}

					//format 3/4
					else
					{
						temporary=0;
						flag=1;
						
						
						commandLine[i].format=3;
						
						//save opcode number into the object code
						objectCode=(int)(searchOpcode->attributes.codeNum);
						
						//for constant x
						if(strchr(commandLine[i].operand,','))
						{

					
							strcpy(temp,commandLine[i].operand);

							if(temp[0]=='@' || temp[0]=='#')
								cutChar=strtok(&temp[1],",");
							
							else	
								cutChar=strtok(temp,",");
							
							if(!IsSymbolInTable(cutChar))
							{
								printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
								inputErr=1;
							}

							cutChar=strtok(NULL,"\n");
							
							if(strcmp(cutChar,"X")!=0)
							{
								printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
								inputErr=1;
							}


							temporary+=8;
							flag=-1;
						}
						
						//direct addressing
						if(commandLine[i].operand[0]=='@')
						{
							objectCode+=INDIRECT;
	
							//there is x in the operand
							if(flag==-1)
							{
								strcpy(temp,&commandLine[i].operand[1]);
								cutChar=strtok(temp,",");
								addressOfOperand=SearchSymbolNumber(cutChar);
							}
							else
							{
								addressOfOperand=SearchSymbolNumber(&commandLine[i].operand[1]);
								if(addressOfOperand==StringToDecimal(&commandLine[i].operand[1]))
								{	
										printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
										inputErr=1;
		//								return;
								}
								
							
							}
							
						}
						
						//immediate addressing
						else if(commandLine[i].operand[0]=='#')
						{
							
							objectCode+=IMMEDIATE;

							if(IsDecimal(&commandLine[i].operand[1]))
								constantFlag=1;
							//there is x in the operand
							
							
							if(flag==-1)
							{
								strcpy(temp,&commandLine[i].operand[1]);
								cutChar=strtok(temp,",");
								addressOfOperand=SearchSymbolNumber(cutChar);
							}
							else
							{
								addressOfOperand=SearchSymbolNumber(&commandLine[i].operand[1]);
								//wrong operand
								if(addressOfOperand==StringToDecimal(&commandLine[i].operand[1]))
								{	
									//it is not both symbor and decimal
									if(!IsDecimal(&commandLine[i].operand[1]))
									{
										printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
										inputErr=1;
		//								return;
									}
								}
							
							}
						}

						//simple addressing
						else
						{
							objectCode+=SIMPLE;
						
							if(flag==-1)
							{
								strcpy(temp,&commandLine[i].operand[0]);
								cutChar=strtok(temp,",");
								addressOfOperand=SearchSymbolNumber(cutChar);
							}
							else
							{
									addressOfOperand=SearchSymbolNumber(&commandLine[i].operand[0]);
									
								//wrong operand	it is not symbol
								if(addressOfOperand==StringToDecimal(&commandLine[i].operand[0]) && commandLine[i].operand[0]!='\0')
								{	
										printf("[ERROR] %06X : [WRONG OPERAND]\n",commandLine[i].location);
										inputErr=1;
		//								return;
								}
							}

						}
						
						objectCode*=16;	
													
					
						if(commandLine[i].operand[0]=='\0')
							objectCode*=16*16*16;

						//we can use pc register then temporary=[xbpe]->+2 
						else if(addressOfOperand-registerPC>-4096 && addressOfOperand-registerPC< 4096)
						{	
							commandLine[i].format=3;
							//operand is constant
							if(constantFlag==1)
							{
								objectCode*=16*16*16;
								temporary=addressOfOperand;
							}
							else{
								temporary+=2;
								objectCode+=temporary; 
								objectCode*=16*16*16;
							
									temporary=addressOfOperand-registerPC;
							}
								
								objectCode+=(4095&temporary); //add the displacement into obj code
							
						}
						
						
						//format 4
						else if(format4Flag==1)
						{
							commandLine[i].format=4;
							objectCode+=1;
							objectCode*=16*16*16*16*16;
							
							
							temporary=addressOfOperand;
							objectCode+=temporary;		

							strcpy(temp2,"+");
							strcat(temp2,commandLine[i].op_code);
							strcpy(commandLine[i].op_code,temp2);
						}
						
						
						else if(addressOfOperand-baseRegister>-4096 && addressOfOperand-baseRegister<4096)
						{
							commandLine[i].format=3;
							if(constantFlag==1)
							{
								temporary=addressOfOperand;
								objectCode*=16*16*16;
							}
							else{
								temporary+=4;
								objectCode+=temporary;
								objectCode*=16*16*16;
							
								temporary=addressOfOperand-baseRegister;
							}
							objectCode+=(4095&temporary); //add the displacement into obj code
						}

						//format does not exits
						else
						{
							printf("[ERROR] %06X : [FORMAT DOES NOT EXIST]\n",commandLine[i].location);
							inputErr=1;

						}
					}
			
					break;
				}

			}

		}

		commandLine[i].objectCode=objectCode;
	
	}
	return;

}

int IsDecimal(char* num)
{
	int i=0;
	
	while(num[i]!='\0')
	{
		if(!(num[i]>='0' && num[i]<='9'))
			return 0;
		i++;
	}
	
	return 1;
}

int StringToDecimal(char* num)
{
	int i=0;
	int NUM=0;
	while(num[i]!='\0')
	{
		if('0'<=num[i] && '9'>=num[i])
		{
			if(i==0)
				NUM=num[i]-'0';
			else
				NUM=NUM*10+(num[i]-'0');
		}
		else
			return -1; //there is inadequate num
		i++;
	}
	return NUM;

}

int StringToHexadecimal(char* num)
{
	int i=0;
	int NUM=0;
	while(num[i]!='\0')
	{
		if(IsHexadecimal(num[i]))
		{
			if(i==0)
				NUM=ParameterToHex(num[i]);
			else
				NUM=NUM*16+(ParameterToHex(num[i]));
		}
		else
			return -1;
		i++;
	}
	return NUM;

}

void EliminateWhiteSpace(char* operand,char** fixedOperand)
{
	char *cutChar;
	
	*fixedOperand = (char*)malloc(sizeof(char)*50);
	cutChar=strtok(operand," 	");
	strcpy(*fixedOperand,cutChar);
	
	cutChar=strtok(NULL," 	");
	while(cutChar!=NULL)
	{
		strcat(*fixedOperand,cutChar);
		cutChar=strtok(NULL," 	");
	}

	return;
}

int FindRegisterNumber(char reg)
{
	switch(reg)
	{
		case 'A' : return 0;
		case 'X' : return 1;
		case 'L' : return 2;	
		case 'B' : return 3;
		case 'S' : return 4;
		case 'T' : return 5;
		case 'F' : return 6;

	}
	return -1;

}

int SearchSymbolNumber(char* cutChar)
{
	
	int location;
	table* index;

	index=symTab;
	
	while(index)
	{
		if(strcmp(index->symbol,cutChar)!=0)
			index=index->next;
		else	
		{
			location=index->location;
			return location;
		}

	}

	//if cutChar is constant
	return StringToDecimal(cutChar);
}

int IsSymbol(char* symbol)
{
	int i=0;

	if(symbol[0]>='0' && symbol[0]<='9')
		return 0;

	while(symbol[i]!='\0')
	{
		if(symbol[i]>='0' && symbol[i]<='9')
		{;}
		else if (symbol[i]>='A' && symbol[i]<='Z')
		{;}

		else 
			return 0;
		i++;
	}

	return 1;
}

int IsSymbolInTable(char* symbol)// check if the input is in the symTab
{
	table* temporary;
	temporary=symTab;

	while(temporary!=NULL)
	{
		if(SAME_STR(symbol,temporary->symbol))
			return 1;
		temporary=temporary->next;

	}
	return 0;
}

int IsOpcode(char* opcode)
{
	int hashNumber;
	opcodelLinkedList* searchOpcode;

	hashNumber=ProcessOpcodeToHash(opcode);
	searchOpcode=opcodeList[hashNumber];

	while(searchOpcode)
	{
		if(strcmp(searchOpcode->attributes.code, opcode)!=0)
			searchOpcode=searchOpcode->next;
		else
			return 1;
	}

	return 0;

}

int IsHexadecimal(char c)
{
	if(c>='0' && c<='9')
		return 1;
	else if(c>='a' && c<='f')
		return 1;
	else if(c>='A' && c<='F')
		return 1;
	
	return 0;
}

int ParameterToHex(char c)
{
	if(c>='0' && c<='9')
		return c-'0';

	switch(c)
	{
		
		case 'a' : return 10;
		case 'b' : return 11;
		case 'c' : return 12;
		case 'd' : return 13;
		case 'e' : return 14;
		case 'f' : return 15;
		case 'A' : return 10;
		case 'B' : return 11;
		case 'C' : return 12;
		case 'D' : return 13;
		case 'E' : return 14;
		case 'F' : return 15;
	}

	return -1;
}

void AssemblePassTwoList(FILE* fpListFileStream,FILE* fpObjectFileStream)
{
	int objectCode;
	int i,j;
	int k,l;
	int objectCounter;
	int location;
	char symbol[MAX_COM_LEN];
	char tempOpcode[MAX_COM_LEN];
	char operand[MAX_COM_LEN];
	//start making a list file
	AssemblePassTwoObject(fpObjectFileStream); 
	
	if(inputErr==1)
		return;

	for(i=0;i<indexCommand;i++)
	{
		strcpy(symbol,commandLine[i].symbol);
		strcpy(tempOpcode,commandLine[i].op_code);
		strcpy(operand,commandLine[i].operand);
		
		
		location=commandLine[i].location;
		objectCode=commandLine[i].objectCode;
	
		if(symbol!=NULL)
		{

			if(objectCode==-1 || SAME_STR(tempOpcode,"START") || SAME_STR(tempOpcode,"END"))
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s\n",5*(i+1),location,symbol,tempOpcode,operand);
			else
			{
			
				if(commandLine[i].format==1)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s%02X\n",5*(i+1),location,symbol,tempOpcode,operand,objectCode);
				else if(commandLine[i].format==2)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s%04X\n",5*(i+1),location,symbol,tempOpcode,operand,objectCode);
				else if(commandLine[i].format==3)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s%06X\n",5*(i+1),location,symbol,tempOpcode,operand,objectCode);
				else if(commandLine[i].format==4)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s%08X\n",5*(i+1),location,symbol,tempOpcode,operand,objectCode);
				else if(SAME_STR(commandLine[i].op_code,"BYTE"))
				{
					if(commandLine[i].operand[0]=='X')
					{
						fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s",5*(i+1),location,symbol,tempOpcode,operand);
						l=2;
						while(commandLine[i].operand[l]=='0')
						{
							fprintf(fpListFileStream,"0");
							l++;
						}

						fprintf(fpListFileStream,"%X\n",commandLine[i].objectCode);
					}
					else
					{
					fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s",5*(i+1),location,symbol,tempOpcode,operand);
					l=0;
					while(commandLine[i].obj[l]!='\0'){
					fprintf(fpListFileStream,"%02X",commandLine[i].obj[l]);
	
					l++;
					}
					fprintf(fpListFileStream,"\n");
					}
				}
				 
				 else
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%-10s%X\n",5*(i+1),location,symbol,tempOpcode,operand,objectCode);
			
			
			}
			
		}

		else if(symbol==NULL)
		{
			if(objectCode==-1 || SAME_STR(tempOpcode,"START") || SAME_STR(tempOpcode,"END"))
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s\n",5*(i+1),location,tempOpcode,operand);
			else
			{
		
				 if(commandLine[i].format==1)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%02X\n",5*(i+1),location,tempOpcode,operand,objectCode);
				else if(commandLine[i].format==2)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%04X\n",5*(i+1),location,tempOpcode,operand,objectCode);
				else if(commandLine[i].format==3)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%06X\n",5*(i+1),location,tempOpcode,operand,objectCode);
				else if(commandLine[i].format==4)
				fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%08X\n",5*(i+1),location,tempOpcode,operand,objectCode);
				else if(SAME_STR(commandLine[i].op_code,"BYTE"))
				{
					if(commandLine[i].operand[0]=='X')
					{
						fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s",5*(i+1),location,tempOpcode,operand);
						l=2;
						while(commandLine[i].operand[l]=='0')
						{
							fprintf(fpListFileStream,"0");
							l++;
						}

						fprintf(fpListFileStream,"%X\n",commandLine[i].objectCode);
					}
					else
					{
					fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s",5*(i+1),location,tempOpcode,operand);
					l=0;
					while(commandLine[i].obj[l]!='\0'){
					fprintf(fpListFileStream,"%02X",commandLine[i].obj[l]);
	
					l++;
					}
					fprintf(fpListFileStream,"\n");
					}

				}
				 else
					fprintf(fpListFileStream,"%-6d%04x   %-10s%-10s%X\n",5*(i+1),location,tempOpcode,operand,objectCode);
			
			
			}
		}
		
	}

	
	//make Header record
	fprintf(fpObjectFileStream,"H");
	
	//program title
	fprintf(fpObjectFileStream,"%-6s",commandLine[0].symbol);
	
	//starting address
	fprintf(fpObjectFileStream,"%06X",commandLine[0].location); 
	
	fprintf(fpObjectFileStream,"%06X",commandLine[indexCommand-1].location-commandLine[0].location);
	fprintf(fpObjectFileStream,"\n");

	//make Text record
	for(i=1;i<indexCommand-1;)
	{
		if(commandLine[i].objectCode!=-1)
		{

			fprintf(fpObjectFileStream,"T");
			fprintf(fpObjectFileStream,"%06X",commandLine[i].location);//print starting address
			
			objectCounter=0;
			//search the length of object code
			for(j=i+1;j<indexCommand;j++)
			{
				if(/*objectCounter>60 ||*/ commandLine[j].location-commandLine[i].location>30 || SAME_STR(commandLine[j].op_code,"RESB") || SAME_STR(commandLine[j].op_code,"RESW"))
					break;
				
			}

			if(commandLine[j].location-commandLine[i].location<=30 && (SAME_STR(commandLine[j].op_code,"RESB") || SAME_STR(commandLine[j].op_code,"RESW")))
				j++;
			//exclude non object code line
			objectCounter=commandLine[j-1].location-commandLine[i].location;
			
			k=j-1;
			while(commandLine[k].objectCode==-1 && strcmp(commandLine[k].op_code,"RESB")!=0 && strcmp(commandLine[k].op_code,"RESW")!=0)
			{	
				k--;
				objectCounter=commandLine[k+1].location-commandLine[i].location;
				
			}

		//	fprintf(fpObjectFileStream,"%02X",commandLine[j-1].location-commandLine[i].location);
			fprintf(fpObjectFileStream,"%02X",objectCounter);
		
			//print the object code
			for(k=i;k<j-1;k++)
			{
				if(commandLine[k].objectCode!=-1)
				{
					 if(commandLine[k].format==1)
					fprintf(fpObjectFileStream,"%02X",commandLine[k].objectCode);
					else if(commandLine[k].format==2)
					fprintf(fpObjectFileStream,"%04X",commandLine[k].objectCode);
					else if(commandLine[k].format==3)
					fprintf(fpObjectFileStream,"%06X",commandLine[k].objectCode);
					else if(commandLine[k].format==4)
					fprintf(fpObjectFileStream,"%08X",commandLine[k].objectCode);
					else if(SAME_STR(commandLine[k].op_code,"BYTE"))
					{
						if(commandLine[k].operand[0]=='X')
						{
							l=2;
							while(commandLine[k].operand[l]=='0')
							{
								fprintf(fpObjectFileStream,"0");
								l++;
							}

							fprintf(fpObjectFileStream,"%X",commandLine[k].objectCode);
						
						}
						else
						{
							l=0;
						while(commandLine[k].obj[l]!='\0'){
						fprintf(fpObjectFileStream,"%02X",commandLine[k].obj[l]);
						
						l++;
						}

						}
					}
					else
							fprintf(fpObjectFileStream,"%X",commandLine[k].objectCode);
					
				}

			}
			fprintf(fpObjectFileStream,"\n");		
			
			if(i+1<j)
				i=j-1;
		
			else
				i=j;
		}//until here
		else
			i++;
	}
	
	for(i=0;i<indexCommand;i++)
	{
		//format 4
		if(commandLine[i].op_code[0]=='+' && commandLine[i].operand[0]!='#')
			fprintf(fpObjectFileStream,"M%06X05\n",commandLine[i].location+1);
	}
	
	fprintf(fpObjectFileStream,"E");
	fprintf(fpObjectFileStream,"%06X",commandLine[0].location);
	fprintf(fpObjectFileStream,"\n");

	return;
}

void DisplayFileContent(char *fileName)
{
	FILE *fp= fopen(fileName,"r");

	if(fp != NULL)
	{
		char c;

		while((c = fgetc(fp)) != EOF)
		{
			putchar(c);
		}
	}
	else
		printf("[ERROR] FILE WAS NOT FOUND!\n");

	fclose(fp);

	return;
}

//Show content of the Symbol Table
void ShowSymbolTable()
{
//	int i;
	table* index;
	index=symTab;

	while(index)
	{
		printf("\t%s\t%04x\n",index->symbol,index->location);
		index=index->next;
	}

	return;

}

void AddToSymbolTable(commandStruct currentCommand)	//add to symbol table
{
	table* temporary;
	table* previous;
	table* after;
	//the symTab is empty

	//the symbol is wrong
	
	if(IsSymbol(currentCommand.symbol)==0)
	{
		inputErr=1;
		printf("[ERROR] %06X : [WRONG LABEL]\n",currentCommand.location);
		return;
	}

	
	if(symTab==NULL)	
	{
		temporary=(table*)malloc(sizeof(table));
		strcpy(temporary->symbol,currentCommand.symbol);
		temporary->location=currentCommand.location;
		temporary->next=NULL;
		symTab=temporary;
	}
	
	//arrange in descending order
	else
	{
		after=previous=symTab;

		temporary=(table*)malloc(sizeof(table));
		strcpy(temporary->symbol,currentCommand.symbol);
		temporary->location=currentCommand.location;
		temporary->next=NULL;

		if(strcmp(symTab->symbol, currentCommand.symbol)<=0)
		{
			temporary->next=symTab;
			symTab=temporary;
		}
		else
		{
			while(after!=NULL && strcmp(after->symbol, currentCommand.symbol) >0 )
			{
				previous=after;
				after=after->next;
			}
		

			if(after!=NULL)
			{
				previous->next=temporary;
				temporary->next=after;
			}
			
			else if(after==NULL)
			{
				previous->next=temporary;	
				temporary->next=NULL;
			}

		}

	}
	return ;
}

int IsThereSymbolTag(commandStruct currentCommand)
{
	table *temporary;
	temporary=symTab;

	while(temporary!=NULL)
	{
		if(SAME_STR(currentCommand.symbol,temporary->symbol))
			return 0;
		temporary=temporary->next;
	}

	return 1;
}
