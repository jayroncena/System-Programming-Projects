#!/usr/bin/python
# -*- coding: utf-8 -*-

from sys import stdin, stdout

inputWord=""

while True:
	inputLine = stdin.readline().strip() #Receive input values line by line from the input file (remove leading and trailing spaces)
	if inputLine == "":# Exit while statement if all of the content of the file is read						 
		break
		
	inputWord=""							 
	words = inputLine.split()# Separate words one by one by breaking them in blanks				 
	
	for word in words:				
		if inputWord:					 
			stdout.write(inputWord + "\t" + word + "\t1\n")# write in map_result text file
			
		inputWord = word						 
