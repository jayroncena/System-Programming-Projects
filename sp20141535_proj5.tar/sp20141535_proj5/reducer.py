#!/usr/bin/python
# -*- coding: utf-8 -*-

from sys import stdin, stdout

dictionary = {}		

while True:

	inputLine = stdin.readline().strip()
	
	if inputLine == "":							
		break

	varA, varB, count = inputLine.split('\t')	

	var = varA + "\t" + varB					
	var = var.lower()
	
	if var in dictionary:						
		dictionary[var] += int(count)
		
	else:
		dictionary[var] = int(count) 

newDictionary=sorted(dictionary)					

	
for var in newDictionary:
	stdout.write(var + "\t" + str(dictionary[var]) + "\n")
